//
//  Enum.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 30/11/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// ---------------------------------------------------------------------
// 서버로 요청한 url 결과 관련 Enum
// ---------------------------------------------------------------------
enum RequestURLError: String, Error {
    case URLRequest = "RequestURLError: URLRequest error"
    case URLSession = "RequestURLError: URLSession error"
    case URLSessionData = "RequestURLError: URLSession Data error"
    case HTTPURLResponse = "RequestURLError: HTTPURLResponse error"
    case JsonConversion = "RequestURLError: JsonConversion error"
    case Unknown = "RequestURLError: Unknown error"
}

// ---------------------------------------------------------------------
// 서버로부터 수신한 JSON포맷의 파싱 결과 관련 Enum
// ---------------------------------------------------------------------
enum ResponseDataError: String, Error {
    case RequestURLForJSON = "ResponseDataError: RequestURLForJSON error"
    case JsonParsing = "ResponseDataError: JSON parsing error"
    case JsonProtocol = "ResponseDataError: JSON Protocol error"
    case ReturnValue = "ResponseDataError: Json key 'success' value is false"
    case Timeout = "ResponseDataError: Timeout(5 seconds)"
    case Unknown = "ResponseDataError: Unknown error"
}

// 20200821 애니메이션 방향
enum AnimationDirection: Int, Error {
    case LeftToRight = 1
    case RightToLeft = 2
    case TopToBottom = 3
    case BottomToTop = 4
}

// -----------------------------------------------------------------------
// enum을 iteration하기 위한 함수 정의
// -----------------------------------------------------------------------
func IterateEnum<T: Hashable>(_: T.Type) -> AnyIterator<T> {
    var i = 0
    return AnyIterator {
        let next = withUnsafeBytes(of: &i) { $0.load(as: T.self) }
        if next.hashValue != i { return nil }
        i += 1
        return next
    }
}
