//
//  RequestURLForJSON.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 14/11/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

//kCFURLErrorUnknown   = -998,
//kCFURLErrorCancelled = -999,
//kCFURLErrorBadURL    = -1000,
//kCFURLErrorTimedOut  = -1001,
//kCFURLErrorUnsupportedURL = -1002,
//kCFURLErrorCannotFindHost = -1003,
//kCFURLErrorCannotConnectToHost    = -1004,
//kCFURLErrorNetworkConnectionLost  = -1005,
//kCFURLErrorDNSLookupFailed        = -1006,
//kCFURLErrorHTTPTooManyRedirects   = -1007,
//kCFURLErrorResourceUnavailable    = -1008,
//kCFURLErrorNotConnectedToInternet = -1009,
//kCFURLErrorRedirectToNonExistentLocation = -1010,
//kCFURLErrorBadServerResponse             = -1011,
//kCFURLErrorUserCancelledAuthentication   = -1012,
//kCFURLErrorUserAuthenticationRequired    = -1013,
//kCFURLErrorZeroByteResource        = -1014,
//kCFURLErrorCannotDecodeRawData     = -1015,
//kCFURLErrorCannotDecodeContentData = -1016,
//kCFURLErrorCannotParseResponse     = -1017,
//kCFURLErrorInternationalRoamingOff = -1018,
//kCFURLErrorCallIsActive               = -1019,
//kCFURLErrorDataNotAllowed             = -1020,
//kCFURLErrorRequestBodyStreamExhausted = -1021,
//kCFURLErrorFileDoesNotExist           = -1100,
//kCFURLErrorFileIsDirectory            = -1101,
//kCFURLErrorNoPermissionsToReadFile    = -1102,
//kCFURLErrorDataLengthExceedsMaximum   = -1103,

// =========================================================================
// 서버로부터 JSON 포맷으로 응답을 받기 위한 URL 요청과 응답시 콜백 처리
// =========================================================================
func SendRequestForJSON(requestURL:URLRequest?) -> (Bool?, RequestURLError?, Int?, String?, Dictionary<String, Any>?) {
    
    // 디버그 창에 요청 내용 출력
    if let req = requestURL {
        p("--------------- requestURL --------------------------------------------")
        p(req)
        if let body = req.httpBody {
            p(NSString(data: body, encoding: String.Encoding.utf8.rawValue)!)
        }
        p("-----------------------------------------------------------------------")
    }
    
    var ok:Bool = false
    var reqUrlError:RequestURLError?
    var err_code:Int = 0
    var err_msg:String? = nil
    var json = Dictionary<String, Any>()
    
    // URL에 실제 접속 및 응답 처리용 콜백 정의
    // -------------------------------------------------
    guard let request = requestURL else {
        return (false, RequestURLError.URLRequest, err_code, err_msg, nil)
    }
    
    var task:URLSessionDataTask
    let sem = DispatchSemaphore.init(value: 0)
    
    let config = URLSessionConfiguration.default
    config.timeoutIntervalForRequest = TimeInterval(4)      // timeout 시간
    config.timeoutIntervalForResource = TimeInterval(10)
    let urlSession = URLSession(configuration: config)
    
    task = urlSession.dataTask(with: request) { data, response, error in
        defer {
            sem.signal()
        }
        do {
            // 기본적인 네트워크 에러 처리
            // -------------------------------------------------
            
            guard error == nil else {
                p("RequestURLError=URLSession.shared.dataTask:[[\(error.debugDescription)]]")
                let err = error as NSError?
                err_code = err!.code
                err_msg = err?.localizedDescription
                // cancel일 경우
                throw RequestURLError.URLSession
            }
            
            guard let data = data else {
                p("RequestURLError=[\(error.debugDescription)]")
                throw RequestURLError.URLSessionData
            }
            
            // http 응답 상태 체크
            // -------------------------------------------------
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                // check for http errors
                p("statusCode should be 200, but is \(httpStatus.statusCode)")
                p("response = \(String(describing: response))")
                throw RequestURLError.HTTPURLResponse
            }
            
            // 대괄호로 묶여 올경우에는 배열(Array<Any>)로 받아서 첫번째 인자를 추출하여 사용
            // -------------------------------------------------
            if let responseJSON = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? Array<Any> {
                // 대괄호로 묶인 JSON 포맷이라 첫번째를 추출하는 방식으로 해야 함
                // ------------------------------------
                json = responseJSON.first as! Dictionary<String, Any>
            }
            else {
                // 대괄호 없이 처음부터 JSON 포맷으로 올경우 Dictionary<String,Any>로 받아서 사용
                // -------------------------------------------------
                if let responseJSON = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? Dictionary<String,Any> {
                    json = responseJSON
                }
                else {
                    throw RequestURLError.JsonConversion
                }
            }
            
            //p(json)
            
            ok = true
            
        }
        catch let error as RequestURLError {
            p("[RequestURLError] \(error.rawValue)")
            ok = false
            reqUrlError = error
        }
        catch let error as NSError {
            p("[NSError  ] \(error.debugDescription)")
            ok = false
            reqUrlError = RequestURLError.Unknown
            err_code = error.code
            err_msg = error.localizedDescription
        }
    }

    // 결과값에 대한 변수들 초기화
    ok = false
    reqUrlError = nil
    err_code = 0
    err_msg = nil
    
    // 요청 작업 실행 및 종료 대기
    task.resume()
    sem.wait()

    p("------ ok=\(ok)")

    if (reqUrlError != nil) { p("reqUrlError=\(reqUrlError!)") }
    if (err_code != 0) { p("err_code=\(err_code)") }

    switch err_code {
        case -1001:
            err_msg = "인터넷 등의 문제로 시간이 초과되었습니다.\r\nReload 아이콘을 탭하여 재시도 해보시고,\r\n지속적으로 문제가 발생하는 경우에는 관리자에게 문의 바랍니다."
        case -1003:
            err_msg = "서버 주소를 찾을 수 없습니다.\r\n서버 주소를 확인해 주세요"
        case -1004:
            err_msg = "서버에 접속을 할 수 없습니다.\r\nReload 아이콘을 탭하여 재시도 해보시고,\r\n지속적으로 문제가 발생하는 경우에는 인터넷 연결 상태 확인\r\n또는 관리자에게 문의 바랍니다."
        case -1005:
            err_msg = "네트워크 상태가 불안정합니다.\r\nReload 아이콘을 탭하여 재시도 해보시고,\r\n지속적으로 문제가 발생하는 경우에는 인터넷 연결 상태 확인\r\n또는 관리자에게 문의 바랍니다."
        case -1009:
            err_msg = "인터넷(WIFI) 연결을 확인해 주세요."
        default:
            break
    }

    if (err_msg != nil) { p("err_msg=\(err_msg!)") }
    p("json=\(json)")
    
    //p("--------------- requestURL End ----------------------------------------")
    return (ok, reqUrlError, err_code, err_msg, json)
    
}


// =========================================================================
// 서버 디렉토리에 파일 업로드 요청
// =========================================================================
func SendRequestForUpload(requestURL:URLRequest?, bodyData:Data?) -> (Bool?, RequestURLError?, Int?, String?, Dictionary<String, Any>?) {
    
    // 디버그 창에 요청 내용 출력
    if let req = requestURL {
        p("Upload, --------------- requestURL -------------------------------------")
        p("Upload,", req)
        if let body = req.httpBody {
            p("Upload,", NSString(data: body, encoding: String.Encoding.utf8.rawValue)!)
        }
        p("Upload, ----------------------------------------------------------------")
    }
    
    var ok:Bool = false
    var reqUrlError:RequestURLError?
    var err_code:Int = 0
    var err_msg:String? = nil
    var json = Dictionary<String, Any>()
    
    // URL에 실제 접속 및 응답 처리용 콜백 정의
    // -------------------------------------------------
    guard let request = requestURL else {
        return (false, RequestURLError.URLRequest, err_code, err_msg, nil)
    }
    
    var task:URLSessionUploadTask
    let sem = DispatchSemaphore.init(value: 0)

    
    task = URLSession.shared.uploadTask(with: request, from: bodyData) { data, response, error in
        defer {
            sem.signal()
        }
        do {
            // 기본적인 네트워크 에러 처리
            // -------------------------------------------------
            guard error == nil else {
                p("Upload, RequestURLError=URLSession.shared.uploadTask:[[\(error.debugDescription)]]")
                let err = error as NSError?
                err_code = err!.code
                err_msg = err?.localizedDescription
                // cancel일 경우
                throw RequestURLError.URLSession
            }
            
            guard let data = data else {
                p("Upload, RequestURLError=[\(error.debugDescription)]")
                throw RequestURLError.URLSessionData
            }
            
            // http 응답 상태 체크
            // -------------------------------------------------
            if let httpStatus = response as? HTTPURLResponse, httpStatus.statusCode != 200 {
                // check for http errors
                p("Upload, statusCode should be 200, but is \(httpStatus.statusCode)")
                p("Upload, response = \(String(describing: response))")
                throw RequestURLError.HTTPURLResponse
            }
            
            // 대괄호로 묶여 올경우에는 배열(Array<Any>)로 받아서 첫번째 인자를 추출하여 사용
            // -------------------------------------------------
            if let responseJSON = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? Array<Any> {
                // 대괄호로 묶인 JSON 포맷이라 첫번째를 추출하는 방식으로 해야 함
                // ------------------------------------
                json = responseJSON.first as! Dictionary<String, Any>
            }
            else {
                // 대괄호 없이 처음부터 JSON 포맷으로 올경우 Dictionary<String,Any>로 받아서 사용
                // -------------------------------------------------
                if let responseJSON = try JSONSerialization.jsonObject(with: data as Data, options: .allowFragments) as? Dictionary<String,Any> {
                    json = responseJSON
                }
                else {
                    throw RequestURLError.JsonConversion
                }
            }
            
            //p("Upload, resopnse json:", json)
            
            ok = true
            
        }
        catch let error as RequestURLError {
            p("Upload, [RequestURLError] \(error.rawValue)")
            ok = false
            reqUrlError = error
        }
        catch let error as NSError {
            p("Upload, [NSError  ] \(error.debugDescription)")
            ok = false
            reqUrlError = RequestURLError.Unknown
            err_code = error.code
            err_msg = error.localizedDescription
        }
    }
    
    ok = false
    reqUrlError = nil
    err_code = 0
    err_msg = nil
    
    task.resume()
    sem.wait()              // task 끝날때까지 기다리자
    
//    p("Upload, --------------- result")
//    p("Upload, ok=\(ok)")
//    p("Upload, reqUrlError=\(reqUrlError)")
//    p("Upload, err_code=\(err_code)")

    switch err_code {
    case -1001:
        err_msg = "Upload, 인터넷 등의 문제로 시간이 초과되었습니다.\r\n관리자에게 문의 바랍니다."
    case -1003:
        err_msg = "Upload, 서버 주소를 찾을 수 없습니다.\r\n서버 주소를 확인해 주세요"
    case -1004:
        err_msg = "Upload, 서버에 접속을 할 수 없습니다.\r\n인터넷 연결 상태 확인 또는 관리자에게 문의 바랍니다."
    case -1005:
        err_msg = "Upload, 네트워크 상태가 불안정합니다.\r\n잠시 후 재시도 바랍니다."
    case -1009:
        err_msg = "Upload, 인터넷(WIFI) 연결을 확인해 주세요."
    default:
        break
    }
//    p("Upload, err_msg=\(err_msg)")
    p("Upload, json=\(json)")
//
    //p("Upload, --------------- requestURL End --------------------------------")
    return (ok, reqUrlError, err_code, err_msg, json)

    
}

