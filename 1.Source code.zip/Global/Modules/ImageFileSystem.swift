//
//  ImageFileSystem.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 12/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

func saveImage(image: UIImage, filename: String, subpath:String) -> Bool {
    var f = filename
    if (subpath != "") {
        if (!mkdirInDocument(createDirectoryName: subpath)) {
            return false
        }
        f = subpath + "/" + f
    }
    
//    guard let data = image.jpegData(compressionQuality: 0.623) else {
//        return false
//    }
    guard let data = image.jpegData(compressionQuality: 1) else {           // 20200826
        return false
    }

    do {
        try data.write(to: DocumentsDirectoryURL.appendingPathComponent(f))
        return true
    } catch {
        p(error.localizedDescription)
        return false
    }
}

func saveImage(image: UIImage, writeTo: URL) -> Bool {

//    guard let data = image.jpegData(compressionQuality: 0.623) else {
//        return false
//    }
    guard let data = image.jpegData(compressionQuality: 1) else {           // 20200826
        return false
    }

    do {
        try data.write(to: writeTo)
        return true
    } catch {
        p(error.localizedDescription)
        return false
    }
}

func getSavedImage(imageUrl:URL) -> UIImage? {
    return UIImage(contentsOfFile: imageUrl.path)
}


func getSavedImage(filename: String, subpath:String = "") -> UIImage? {
    var f = filename
    if (subpath != "") {
        f = subpath + "/" + f
    }
    return UIImage(contentsOfFile: URL(fileURLWithPath: DocumentsDirectoryURL.absoluteString).appendingPathComponent(f).path)
}


func getFileListInDocument(subpath:String = "") {
    let fileManager = FileManager.default
    
    var fullDirectoryName = DocumentsDirectory
    if (subpath != "") {
        fullDirectoryName = fullDirectoryName + "/" + subpath
    }
    do {
        let filelist = try fileManager.contentsOfDirectory(atPath: fullDirectoryName)
        for filename in filelist {
            let str = filename as NSString
            p("\(str.lastPathComponent)(\(str.deletingPathExtension), \(str.pathExtension))")
        }
    }
    catch {
        p("getFileListInDocument() error : \(error.localizedDescription)")
    }
}

var DocumentsDirectory:String {
    return DocumentsDirectoryURL.path
}

var DocumentsDirectoryURL:URL {
    let paths = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)
    let documentsDirectory = paths[0]
    return documentsDirectory
}

func mkdirInDocument(createDirectoryName:String) -> Bool {
    //let createDorectoryFullName = DocumentsDirectory + "/" + createDirectoryName
    let createDorectoryFullName = DocumentsDirectoryURL.appendingPathComponent(createDirectoryName).path
    p("mkdirInDocumentDirectory() createDorectoryFullName : ", createDorectoryFullName)
    if (makeDir(fullPath: createDorectoryFullName)) {
        return true
    }
    return false
}

func rmdirInDocument(removeDirectoryName:String) -> Bool {
    //let removeDorectoryFullName = DocumentsDirectory + "/" + removeDirectoryName
    let removeDorectoryFullName = DocumentsDirectoryURL.appendingPathComponent(removeDirectoryName).path
    p("rmdirInDocumentDirectory() removeDorectoryFullName : ", removeDorectoryFullName)
    if (removeDir(fullPath: removeDorectoryFullName)) {
        return true
    }
    return false
}

func makeDir(fullPath atPath:String) -> Bool {
    let fileManager = FileManager.default
    do {
        try fileManager.createDirectory(atPath: atPath, withIntermediateDirectories: true, attributes: nil)
        return true
    }
    catch {
        p("makeDir() error : \(error.localizedDescription)")
    }
    return false
}

func removeDir(fullPath atPath:String) -> Bool {
    let fileManager = FileManager.default
    do {
        try fileManager.removeItem(atPath: atPath)
        //p("removeDir : ", atPath)
        return true
    }
    catch {
        p("removeDir() error : \(error.localizedDescription)")
    }
    return false
}

