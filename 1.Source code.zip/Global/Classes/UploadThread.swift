//
//  UploadThread.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 24/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// upload할 이미지 파일 정보
struct ImageInfoToUpload {
    var projectCode: String?    // 프로젝트 코드
    var projectName: String?    // 프로젝트 명
    var imageID: String?        // 소스 이미지 id
    var imageSeq: Int?          // 마킹 이미지 순서 0- , 0이면 기존 이미지 삭제 요청 후 진행
    var name: String?           // 저장할 이름
    var location: String?       // 저장할 위치
    var imageFileURL: URL?      // 업로드할 이미지 파일 URL
}

var ImagesToUpload:[ImageInfoToUpload] = []

class UploadThread: NSObject {
    
    fileprivate var endless = false
    fileprivate var running = false
    
    func runLoop() {
        
        self.running = true
        
        while (endless) {
            if (ImagesToUpload.count > 0) {
                let imageInfoToUpload = ImagesToUpload.removeFirst()
                p("Upload, Trying uploadImageFile : ", imageInfoToUpload.name!, imageInfoToUpload.location! )
                
                // 이미지 순번이 0이면 기존 이미지들을 먼저 삭제 요청
                if (imageInfoToUpload.imageSeq == 0) {
                    let (success, _) = removeMarkedImages(imagePath: imageInfoToUpload.location! , imageID: imageInfoToUpload.imageID!)
                    
                    if (success) {
                        //Thread.sleep(forTimeInterval: 0.1)  20200826
                    }
                }
                
                // 이미지 업로드
                let (success, msg) = uploadImageFile(imageFileURL: imageInfoToUpload.imageFileURL!, serverLocation: imageInfoToUpload.location!, name: imageInfoToUpload.name!)
                
                if (success) {
                    //Thread.sleep(forTimeInterval: 0.1)
                }
                else {
                    p("Upload, uploadImageFile() is failed:", msg)
                    
                    // 재시도하기 위하여 다시 insert
                    ImagesToUpload.insert(imageInfoToUpload, at: 0)
                    Thread.sleep(forTimeInterval: 1)
                }
            }
            else {
                Thread.sleep(forTimeInterval: 0.1)
            }
        }
    }
    
    override init() {
        super.init()
    }
    
    func start() {
        
        if (running) {
            p("이미 업로드 프로세스가 동작중입니다.")
            return
        }
        
        DispatchQueue.global(qos: .background).async {
            p("UploadThread Start")
            self.endless = true
            self.runLoop()
            DispatchQueue.main.async {
                p("UploadThread Stop")
                self.running = false
            }
        }
    }
    
    func stop() {
        if (!running) {
            p("이미 업로드 프로세스가 정지 상태입니다.")
            return
        }
        endless = false
    }
    
}
