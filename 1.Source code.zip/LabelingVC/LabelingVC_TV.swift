//
//  LabelingVC_TV.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 24/10/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC: UITableViewDelegate, UITableViewDataSource  {

    func numberOfSections(in tableView: UITableView) -> Int {
        tableView.rowHeight =
            CGFloat(tableView.frame.height / CGFloat(LabelList.getLabelCount(location: tableView.tag)))
        return 1
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return LabelList.getLabelCount(location: tableView.tag)
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: getCellIdentifier(tableView.tag), for: indexPath)
        
        if (LabelList.getLabelText(location: tableView.tag).count == 0) { return cell }
        
        // data mapping
        let label = LabelList.getLabelText(location: tableView.tag)[indexPath.row]
        let count = mainImageList.countByLabel(target_cd: tableView.tag, label_cd: indexPath.row)
        cell.textLabel!.text = "\(label)\n(\(count))"

        // property mapping
        cell.textLabel?.lineBreakMode = NSLineBreakMode.byCharWrapping
        cell.textLabel?.numberOfLines = 3
        cell.textLabel?.transform = CGAffineTransform(rotationAngle: -CGFloat.pi / 2) // 세로모드
        cell.textLabel?.textAlignment = .center
        
        if (getLastSelectedIndex(tableView.tag) == indexPath.row) {
            cell.textLabel?.textColor = selectedCellTextColor
            //cell.backgroundColor = selectedCellBackgroundColor
            cell.backgroundColor = GetTintColor()

            // 리뷰 모드일 경우에는 선택된 라벨의 글씨 색상을 변경
            if (IsReviewMode) {
                if ((tableView.tag == 0 &&  indexPath.row == LeftIndexOnReviewMode) ||
                    (tableView.tag == 1 &&  indexPath.row == RightIndexOnReviewMode)) {
                    if (GetTintColor() == UIColor.orange) {
                        cell.textLabel?.textColor = UIColor.blue
                    }
                    else {
                        cell.textLabel?.textColor = UIColor.yellow
                    }
                }
            }
            
        }
        else {
            cell.textLabel?.textColor = defaultCellTextColor
            cell.backgroundColor = defaultCellBackgroundColor

            // 리뷰 모드일 경우에는 선택된 라벨의 글씨 색상을 변경
            if (IsReviewMode) {
                if ((tableView.tag == 0 &&  indexPath.row == LeftIndexOnReviewMode) ||
                    (tableView.tag == 1 &&  indexPath.row == RightIndexOnReviewMode)) {
                    cell.textLabel?.textColor = UIColor.blue
                }
            }
            
        }
        
        return cell
    }
    
    func labels(_ tag: Int) -> [String] {
        if (tag == 0) {
            return labelsLeft
        }
        else {
            return labelsRight
        }
    }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        return true
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        setLastSelectedIndex(tableView.tag, indexPath.row)
        checkSaveButtonShow()
        tableView.reloadData()
        
        // 하단 컬렉션 뷰와 동일하게~~~~
        if (tableView.tag == 0) {
            collectionViewBottom.reloadData()
        }
    }
    
    func getCellIdentifier(_ tag: Int) -> String {
        if (tag == 0) {
            return "LabelCellLeft"
        }
        else if (tag == 1) {
            return "LabelCellRight"
        }
        else {
            return ""
        }
    }
    
    func setLastSelectedIndex(_ tag: Int,_ index: Int) {
        let selectedLabelIndex = getLastSelectedIndex(tag)
        if (tag == 0) {
            (selectedLabelIndex == index) ? (selectedLabelLeftIndex = -1) : (selectedLabelLeftIndex = index)
        }
        else if (tag == 1) {
            (selectedLabelIndex == index) ? (selectedLabelRightIndex = -1) : (selectedLabelRightIndex = index)
        }
    }

    func getLastSelectedIndex(_ tag: Int) -> Int {
        if (tag == 0) {
            return selectedLabelLeftIndex
        }
        else if (tag == 1) {
            return selectedLabelRightIndex
        }
        else {
            return -1
        }
    }
    
}
