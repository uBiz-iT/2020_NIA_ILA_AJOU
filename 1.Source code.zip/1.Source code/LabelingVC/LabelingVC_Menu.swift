//
//  LabelingVC_Menu.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 03/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // -----------------------------------------------------------------------------
    // dimming view를 탭하면 실행할 seclector 지정
    // -----------------------------------------------------------------------------
    func setupDimmingViewTapGestureRecognizer(view:UIView) {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(dimmingViewTapped(_:)))
        view.addGestureRecognizer(tapGesture)
    }
    
    // -----------------------------------------------------------------------------
    // dimming view tab selector
    // -----------------------------------------------------------------------------
    @objc func dimmingViewTapped(_ gesture: UITapGestureRecognizer) {
        menuViewController.didTopMenuType?(MenuType.nothing)
        menuViewController.dismiss(animated: true, completion: nil)
        checkHiddenView()
    }
    
    // -----------------------------------------------------------------------------
    // 선택된 메뉴에 해당하는 화면을 콜
    // -----------------------------------------------------------------------------
    func transitionToNewContent(_ menuType: MenuType) {
        
        switch menuType {
        case .login:
            self.performSegue(withIdentifier: "segueLoginOut", sender: self)
            break
        case .projectList:
            self.performSegue(withIdentifier: "segueProjectList", sender: self)
            break
        case .help:
            self.performSegue(withIdentifier: "segueHelp", sender: self)
            break
        case .about:
            self.performSegue(withIdentifier: "segueAbout", sender: self)
            break
        case .labeling:
            self.performSegue(withIdentifier: "segueLabeling", sender: self)
            break
        case .nothing:
            break
        case .setting:
            self.performSegue(withIdentifier: "segueSetting", sender: self)
            break
        }
    }
    
    // -----------------------------------------------------------------------------
    // segue prepare
    // -----------------------------------------------------------------------------
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "segueLoginOut" {
        }
        else if segue.identifier == "segueProjectList" {
            p("loading segueProjectList")
            //let projectVC = (segue.destination as! ProjectVC)
        }
        else if segue.identifier == "segueHelp" {
        }
        else if segue.identifier == "segueAbout" {
        }
        else if segue.identifier == "segueLabeling" {
        }
        else if segue.identifier == "segueReferImages" {
            
            if (currentImageIndex < 0 || currentImageIndex >= imageArray.count) {
                p("Array Index Error : prepare() number \(currentImageIndex)")
                return
            }
            guard let imageID = imageArray[currentImageIndex].id else { return }
            
            // 네비게이션을 통해서 이동할때
            let navi = segue.destination as? UINavigationController
            let slideReferImagesVC = navi?.viewControllers.first as! SlideReferImagesVC
            slideReferImagesVC.projectCode = WorkingProjectCode
            slideReferImagesVC.imageId = imageID
            slideReferImagesVC.imgArr = referImages
            slideReferImagesVC.referImageList = referImageList
            
            // 네비게이션을 통하지 않고 바로 ViewController로 이동할때
            //            let slideReferImagesVC = segue.destination as! SlideReferImagesVC
            //            slideReferImagesVC.projectCode = WorkingProjectCode
            //            slideReferImagesVC.imageId = imageID
            //            slideReferImagesVC.imgArr = referImages
        }
    }
 
    // -----------------------------------------------------------------------------
    // 다른 화면으로 갔다가 돌아올 때 어떻게 할 것인지...
    // -----------------------------------------------------------------------------
    func returnFromOtherScreen(segue : UIStoryboardSegue) {
        displayMenuView = true
        
        isNewLogined = false
        isNewProjectBegan = false
        
        if let id = segue.identifier {
            p("returnFromsegueAction (segue identifier) : ", id)
            if (id == "unwindFromNewProject") {
                isFromProjectMenu = true
                isNewProjectBegan = true
                displayMenuView = false
                
                //새로 프로젝트가 시작되었으면 설정 값을 초기화
                initLabelingSettingItem()
                
            }
            else if (id == "unwindFromProjectList") {
                isFromProjectMenu = true
                isNewProjectBegan = false
            }
            else if (id == "unwindFromNewLogin") {
                isFromLoginMenu = true
                isNewLogined = true
                displayMenuView = false
            }
            else if (id == "unwindFromLoginOut") {
                isFromLoginMenu = true
                isNewLogined = false
            }
            else if (id == "unwindFromReferImages") {
                displayMenuView = false
            }
            else if (id == "unwindFromLabelingSetting") {
                isFromSettingMenu = true
                displayMenuView = false
            }
        }
        
    }
    
}




// -----------------------------------------------------------------------------
// Menu view 표시용
// -----------------------------------------------------------------------------
extension LabelingVC: UIViewControllerTransitioningDelegate {
    func animationController(forPresented presented: UIViewController, presenting: UIViewController, source: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        menuTransition.isPresenting = true
        return menuTransition
    }
    func animationController(forDismissed dismissed: UIViewController) -> UIViewControllerAnimatedTransitioning? {
        menuTransition.isPresenting = false
        return menuTransition
    }
}

