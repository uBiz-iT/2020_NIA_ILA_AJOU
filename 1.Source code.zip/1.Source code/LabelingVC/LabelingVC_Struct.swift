//
//  LabelingVC_Struct.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 2020/08/29.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {

    // ----------------------------------------------------------------------------------------------------------------------
    // 20200829 라베링 및 마크 실적 생성용
    // ----------------------------------------------------------------------------------------------------------------------
    struct LabelingResult: Codable {
        var target_cd: Int?
        var label_cd: Int?
    }
    
    struct Color: Codable {
        var R:CGFloat?
        var G:CGFloat?
        var B:CGFloat?
        var alpha:CGFloat?
        
        init(Red R:CGFloat, Green G:CGFloat, Blue B:CGFloat, alpha a:CGFloat) {
            self.R = R
            self.G = G
            self.B = B
            self.alpha = a
        }
    }
    
    struct MarkResult: Codable {
        var type:Int?
        var isClip:Bool?
        var width:CGFloat?
        var color:Color?
        var fillcolor:Color?
        var shape: [MyPoint] = []
    }
    
    struct RequestSaveLabelingResult: Codable {
        var proc_name: String?
        var project_cd: String?
        var user_id: String?
        var image_id: String?
        var multi_yn: String?
        var whole_yn: String?
        var sub_image_id: String?
        var labeling_ord: Int?
        var result: [LabelingResult] = []
        var mark_num: Int?
        var mark_result: [MarkResult] = []
    }

    // -----------------------------------------------------------------------------------
    // COCO 형태로 json 저장(건별이므로 의미없으나 최대한 네이밍을 맞추기 위함) 20200928
    // -----------------------------------------------------------------------------------
    struct COCO_Image: Codable {
        var file_name: String?
        var height: Int?
        var width: Int?
        var id: String?
    }
    
    struct COCO_Annotation: Codable {
        var segmentation: [[Decimal]] = []
        var area: Decimal?
        var image_id: String?
        var category_id: Int?
    }
    
    struct COCO_Category: Codable {
        var id: Int?
        var name: String?
    }
    
    struct COCO_LabelingResult: Codable {
        var project_cd: String?
        var user_id: String?
        var labeling_order: Int?
        var labeling_date: String?
        var image: COCO_Image?
        var annotation: COCO_Annotation?
        var categories: [COCO_Category] = []
    }
    // -----------------------------------------------------------------------------------
      
    struct MyBoundingBox : Codable {
        var x:Float?
        var y:Float?
        var w:Float?
        var h:Float?
    }

    struct MyPoint : Codable {
        var x:Decimal?
        var y:Decimal?
    }

}
