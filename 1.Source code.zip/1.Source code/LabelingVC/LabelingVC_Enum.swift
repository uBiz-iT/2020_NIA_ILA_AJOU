//
//  LabelingVC_Enum.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    // ---------------------------------------------------------------------
    // drawing color enum
    // ---------------------------------------------------------------------
    enum EnumDrawingColor:Int, CaseIterable{
        case Red = 0, Orange, Yellow, White, Blue
        var color:UIColor { get {
            switch self {
            case .Red:
                return UIColor.red
            case .Blue:
                return UIColor.blue
            case .Yellow:
                return UIColor.yellow
            case .White:
                return UIColor.white
            case .Orange:
                return UIColor.orange
            }
            }}
        var displayColor:UIColor { get {
            switch self {
            case .Red:
                return UIColor.red
            case .Blue:
                return UIColor.blue
            case .Yellow:
                return UIColor.darkYellow
            case .White:
                return UIColor.darkWhite
            case .Orange:
                return UIColor.orange
            }
            }}
        var title:String { get {
            switch self {
            case .Red:
                return "빨강"
            case .Blue:
                return "파랑"
            case .Yellow:
                return "노랑"
            case .White:
                return "하양"
            case .Orange:
                return "주황"
            }
            }}
    }
    
}
