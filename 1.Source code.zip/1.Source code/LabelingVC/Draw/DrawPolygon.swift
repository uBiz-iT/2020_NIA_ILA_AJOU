//
//  DrawPolygon.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 13/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

enum PolygonStatus: String {
    case DrawStarted
    case Moving
    case DrawStopping
    case DrawStopped
}

extension LabelingVC {

    // ------------------------------------------------------
    // long press touch의 경우 실행되어야 함
    // ------------------------------------------------------
    func longPressGesture_Polygon(point:CGPoint) {
        switch polygonStatus {
        case .DrawStopped:
            polygonStatus = .DrawStarted
            p("polygonStatus.rawValue \(polygonStatus.rawValue)")
            drawPolygonStart(point: point)
            break
        case .DrawStarted:
            (isSelectedControlPoint, selectedControlPointPosition) = selectedControlPoint(point: point)
            if (isSelectedControlPoint) {
                removePoint(index: selectedControlPointPosition)
            }
            else {
//                polygonStatus = .Moving
//                p("polygonStatus.rawValue \(polygonStatus.rawValue)")
                polygonStatus = .DrawStopping
                p("polygonStatus.rawValue \(polygonStatus.rawValue)")
                drawEnded_Polygon()
            }
            break
        case .Moving:
            (isSelectedControlPoint, selectedControlPointPosition) = selectedControlPoint(point: point)
            if (isSelectedControlPoint) {
                removePoint(index: selectedControlPointPosition)
            }
            else {
                polygonStatus = .DrawStopping
                p("polygonStatus.rawValue \(polygonStatus.rawValue)")
                drawEnded_Polygon()
            }
            break
        default:
            break
        }
    }
    
    // ------------------------------------------------------
    // 화면 tap의 경우 실행되어야 함
    // ------------------------------------------------------
    func tapGesture_Polygon(point:CGPoint) {
        switch polygonStatus {
        case .DrawStopped:
            longPressGesture_Polygon(point: point)
            return
        case .DrawStarted:
            addPoint(point: point)
            break
        case .Moving:
            // 이동중 상태에서 탭이 발생하면 그리기 상태로 자동 전환
            polygonStatus = .DrawStarted
            p("polygonStatus.rawValue \(polygonStatus.rawValue)")
            addPoint(point: point)
            return
        default:
            return
        }
    }

    // -----------------------------------------------------------
    // 그리기 시작, 첫번째 포인트 및 포인트 콘트롤 생성(long press gesture)
    // -----------------------------------------------------------
    func drawPolygonStart(point:CGPoint) {
        canvas.isDrawing = true
        addStartControlPoint(point: point)
    }
    
    func addStartControlPoint(point:CGPoint) {
        controlPoints.removeAll()
        polygonApex.removeAll()                                         // 기존 포인트 정보 삭제
        addOutlineLayer(view: EditingImage)                                // 이미지 뷰에 다각형 용 레이어 추가
        addPoint(point: point)                                          // 포인트 추가
    }
    
    // -----------------------------------------------------------
    // 포인트 콘트롤 추가(tap gesture)
    // -----------------------------------------------------------
    func addPoint(point:CGPoint) {
        polygonApex.append(point)
        drawPolygonLayer()
        addOneControlPoint(point: point)
    }
    
    func removePoint(index:Int) {
        polygonApex.remove(at: index)
        drawPolygonLayer()
        let controlPoint = controlPoints.remove(at: index)
        controlPoint.removeFromSuperlayer()
    }
    
    func addOutlineLayer(view:UIView) {
        // outline 추가
        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let shapeRect = CGRect(x: 0, y: 0, width: EditingImage.frame.width, height: EditingImage.frame.height)
        
        shapeLayer.fillColor = UIColor.clear.cgColor
        //shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.lineWidth = 3
        shapeLayer.lineDashPattern = [1,1]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
        shapeLayer.frame = view.frame
        outlineLayer = shapeLayer
        
        view.layer.addSublayer(shapeLayer)
    }
    
    
    func addOneControlPoint(point:CGPoint) {

        let x = point.x - 30
        let y = point.y - 30
        
        // 꼭지점마다 컨트롤포인트 추가
        let controlPointSize = CGSize(width: 60, height: 60)
        let controlPointLayer:CAShapeLayer = CAShapeLayer()
        controlPointLayer.fillColor = UIColor.clear.cgColor
        controlPointLayer.strokeColor = controlPointColor.cgColor
        controlPointLayer.lineWidth = 1
        controlPointLayer.path =
            UIBezierPath(ovalIn:CGRect(x: 0, y: 0, width: controlPointSize.width, height: controlPointSize.height)).cgPath
        controlPointLayer.frame = CGRect(origin: CGPoint(x:x,y:y), size: controlPointSize)
        
        outlineLayer.addSublayer(controlPointLayer)
        controlPoints.append(controlPointLayer)

    }
    
    // -----------------------------------------------------------
    // 다각형 그리기
    // -----------------------------------------------------------
    // - 기존에 그려져 있던 다각형을 제거한다.
    // - 꼭지점 정보를 이용하여 다시 그린다.
    // -----------------------------------------------------------
    func drawPolygonLayer() {
        
        polygonLayer.removeFromSuperlayer()

        let path = UIBezierPath()
        for (i, p) in polygonApex.enumerated() {
            if i == 0 {
                path.move(to: p)
            }
            else {
                path.addLine(to: p)
            }
        }
        
        path.close()

        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.fillColor = UIColor.clear.cgColor
        shapeLayer.strokeColor = (isCutMode) ? UIColor.white.cgColor : lineColor.cgColor
        shapeLayer.lineWidth = 2.0
        
        outlineLayer.addSublayer(shapeLayer)
        polygonLayer = shapeLayer

    }

    // -----------------------------------------------------------
    // 이동 시작(pan gesture began)
    // -----------------------------------------------------------
    // - 다각형 자체 또는 꼭지점의 이동 시작 체크
    // - 어떤 것이 선택되었는지를 체크하여 변수에 저장해 놓는다.
    // -----------------------------------------------------------
    func panGestureBegan_Poygon(point:CGPoint) {

        // 꼭지점을 지정하는 중이었으면 움직이는 상태로 자동 전환
        if (polygonStatus == .DrawStarted) {
            polygonStatus = .Moving
            p("polygonStatus.rawValue \(polygonStatus.rawValue)")
        }
        
        if (polygonStatus != .Moving) { return }
        
        panPrevPoint = point
        
        isSelectedPolygon = false
        isSelectedControlPoint = false
        selectedControlPointPosition = -1

        (isSelectedControlPoint, selectedControlPointPosition) = selectedControlPoint(point: point)
        
        if (!isSelectedControlPoint) {
            isSelectedPolygon = selectedPolygon(point: point)
        }
        
    }
    
    // -----------------------------------------------------------
    // 콘트롤 포인터가 선택되었는지 체크
    // -----------------------------------------------------------
    // - 선택된 index와 선택 여부를 반환한다.
    // -----------------------------------------------------------
    func selectedControlPoint(point:CGPoint) -> (Bool, Int) {
        var selected = false
        var idx = -1
        for (index, controlPoint) in controlPoints.enumerated() {
            if controlPoint.frame.contains(point) {
                p("----------------------------- ", controlPoint.frame)
                selected = true
                idx = index
            }
        }
        return (selected, idx)
    }
    
    // -----------------------------------------------------------
    // 다각형 내부가 선택되었는지 체크
    // -----------------------------------------------------------
    // - 선택 여부를 반환한다.
    // -----------------------------------------------------------
    func selectedPolygon(point:CGPoint) -> Bool {
        var selected = false
        if (containsInPolygon(points: polygonApex, point: point)) {
            p("----------------------------- isSelectedPolygon")
            selected = true
        }
        return selected
    }
    
    // -----------------------------------------------------------
    // 이동중(pan gesture moved)
    // -----------------------------------------------------------
    // 선택된 다각형 또는 꼭지점을 이동하고 해당하는 콘트롤 포인트를 이동한다.
    // -----------------------------------------------------------
    func panGestureMoved_Poygon(point:CGPoint) {
        
        if (polygonStatus != .Moving) { return }
        
        if (isSelectedControlPoint) {
            moveControlPoint_Polygon(position: selectedControlPointPosition, point: point)
        }
        else if (isSelectedPolygon) {
            movePolygon(point: point)
        }
        
        panPrevPoint = point
        
    }
    
    // -----------------------------------------------------------
    // 그리기 종료(long press gesture)
    // -----------------------------------------------------------
    func drawEnded_Polygon() {

        if (polygonStatus != .DrawStopping) { return }

        canvas.isDrawing = false
        
        polygonLayer.removeFromSuperlayer()
        for (_, controlPoint) in controlPoints.enumerated() {
            controlPoint.removeFromSuperlayer()
        }
        
        // 콘트롤포인트가 2개(직선) 이상인 경우에만~~
        if (polygonApex.count >= 2) {
            var line = Line(isClip: isCutMode, type: .Polygon, width: lineWidth, color: (isCutMode) ? UIColor.white : lineColor, fillcolor: lineColor, alpha: lineAlpha, points: [], realPoints: [])
            line.points = polygonApex
            
            line.realPoints = getRealPoints(screenPoints: polygonApex)  // 20200830

            canvas.append(line: line)
            canvas.setNeedsDisplay()
            undoButton.isEnabled = true
            redoButton.isEnabled = false    // 20200828

            markCountLabel.text = "\(canvas.lines.count)개"
            if (canvas.lines.count > 0) {
                markUpdated = true
            }
        
        }
        
        polygonStatus = .DrawStopped
    }
    
    // ------------------------------------------------------------------------------
    // 다각형 마크 실제 이동
    // ------------------------------------------------------------------------------
    // - 다각형의 꼭지점의 위치를 변경하고 다시 그린다.
    // - 콘트롤 포인트도 꼭지점의 위치로 이동한다.
    // ------------------------------------------------------------------------------
    func movePolygon(point:CGPoint) {
        
        let gapPoint = CGPoint(x:point.x - panPrevPoint.x, y:point.y - panPrevPoint.y)

        var newApex = [CGPoint]()
        var newPoint:CGPoint
        
        for p in polygonApex {
            newPoint = CGPoint(x: p.x + gapPoint.x, y: p.y + gapPoint.y)
            newApex.append(newPoint)
        }
        
        polygonApex = newApex
        
        drawPolygonLayer()
        
        moveControlPoints_Polygon(gap: gapPoint)

    }
    
    // ------------------------------------------------------------------------------
    // 콘트롤 포인트 이동
    // ------------------------------------------------------------------------------
    // - 다각형의 꼭지점의 위치를 변경하고 다시 그린다.
    // - 콘트롤 포인트도 꼭지점의 위치로 이동한다.
    // ------------------------------------------------------------------------------
    func moveControlPoint_Polygon(position:Int, point:CGPoint) {
        
        let gapPoint = CGPoint(x:point.x - panPrevPoint.x, y:point.y - panPrevPoint.y)
        
        polygonApex[position] = CGPoint(x: polygonApex[position].x + gapPoint.x, y: polygonApex[position].y + gapPoint.y)
        let newControlPointOrigin = CGPoint(x: controlPoints[position].frame.origin.x + gapPoint.x, y: controlPoints[position].frame.origin.y + gapPoint.y)
        
        disableAnimation {
            controlPoints[position].frame.origin = newControlPointOrigin
        }

        // 꼭지점의 위치가 변경되었으니 다각형도 다시 그린다.
        drawPolygonLayer()

    }
    
    // -----------------------------------------------------------
    // 다각형의 모든 꼭지점 위치 변경
    // -----------------------------------------------------------
    // - 다각형의 위치가 변경된 경우에 수행
    // -----------------------------------------------------------
    func moveControlPoints_Polygon(gap:CGPoint) {
        for (index, controlPoint) in controlPoints.enumerated() {
            let newControlPointOrigin = CGPoint(x: controlPoint.frame.origin.x + gap.x, y: controlPoint.frame.origin.y + gap.y)
            disableAnimation {
                controlPoints[index].frame.origin = newControlPointOrigin
            }
        }
    }
    
}


