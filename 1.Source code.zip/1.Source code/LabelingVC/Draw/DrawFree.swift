//
//  DrawFree.swift
//  testSaveImage
//
//  Created by Myeong-Joon Son on 09/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension LabelingVC {
    
    func panGestureBegan_FreeCurve(point:CGPoint) {
        if (canvas.isDrawing) { return }
        addStartFree(point: point)
        canvas.isDrawing = true                                         // 선 그리기 시작
    }
    
    func panGestureMoved_FreeCurve(point:CGPoint) {
        if (!canvas.isDrawing) { return }                               // 선 그리기 상태가 아니면 return
        addFreePoint(point: point)
    }
    
    func panGestureEnded_FreeCurve(point:CGPoint) {
        if (!canvas.isDrawing) { return }                                   // 선 그리기 상태가 아니면 return
        canvas.isDrawing = false                                              // 선 그리기 상태 해제
        
        freeLayer.removeFromSuperlayer()
        
        if (freeApex.count >= 2) {
//            let width = (lineType == .FreeCurve) ? lineWidth : 2.0
//            let alpha = (lineType == .FreeCurve) ? lineAlpha : 0.0
            
            var line = Line(isClip: isCutMode, type: lineType, width: lineWidth, color: (isCutMode) ? UIColor.white : lineColor, fillcolor: UIColor.white, alpha: lineAlpha, points: [], realPoints: []) // 선의 point 배열 생성

            if (lineType == .ClosedCurve) {
                line.fillcolor = line.color
                line.alpha = lineAlpha
            }

            line.points = freeApex
            line.realPoints = getRealPoints(screenPoints: freeApex) // 20200830
            canvas.append(line: line)
            canvas.setNeedsDisplay()
            undoButton.isEnabled = true
            redoButton.isEnabled = false    // 20200828
            
            markCountLabel.text = "\(canvas.lines.count)개"
            if (canvas.lines.count > 0) {
                markUpdated = true
            }

        }
    }
    
    func addStartFree(point:CGPoint) {
        freeApex.removeAll()                                                // 기존 포인트 정보 삭제
        addFreeOutlineLayer(view: EditingImage)                         // 이미지 뷰에 다각형 용 레이어 추가
        addFreePoint(point: point)                                         // 포인트 추가
    }
    
    func addFreeOutlineLayer(view:UIView) {
        // outline 추가
        let shapeLayer:CAShapeLayer = CAShapeLayer()
        let shapeRect = CGRect(x: 0, y: 0, width: EditingImage.frame.width, height: EditingImage.frame.height)
        
        shapeLayer.fillColor = UIColor.clear.cgColor
        //shapeLayer.strokeColor = UIColor.red.cgColor
        shapeLayer.lineWidth = 3
        shapeLayer.lineDashPattern = [1,1]
        shapeLayer.path = UIBezierPath(roundedRect: shapeRect, cornerRadius: 0).cgPath
        shapeLayer.frame = view.frame
        freeOutlineLayer = shapeLayer
        
        view.layer.addSublayer(shapeLayer)
    }
    
    func addFreePoint(point:CGPoint) {
        freeApex.append(point)
        drawFreeLayer()
    }
    
    func drawFreeLayer() {
        
        freeLayer.removeFromSuperlayer()
        
        let path = UIBezierPath()

        for (i, p) in freeApex.enumerated() {
            if i == 0 {
                path.move(to: p)
            }
            else {
                path.addLine(to: p)
                
            }
        }
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = path.cgPath
        shapeLayer.fillColor = UIColor.clear.cgColor
        
        if (isCutMode) {
            let  dashes: [ NSNumber ] = [ 2.0, 2.0 ]
            shapeLayer.lineWidth = 2.0
            shapeLayer.lineDashPattern = dashes
            shapeLayer.lineCap = .round
            shapeLayer.strokeColor = UIColor.white.cgColor
        }
        else {
            shapeLayer.strokeColor = lineColor.cgColor
            shapeLayer.lineCap = .round
            shapeLayer.lineWidth = (lineType == .FreeCurve) ? lineWidth : 2.0
        }

        freeOutlineLayer.addSublayer(shapeLayer)
        freeLayer = shapeLayer
        
    }
    

}
