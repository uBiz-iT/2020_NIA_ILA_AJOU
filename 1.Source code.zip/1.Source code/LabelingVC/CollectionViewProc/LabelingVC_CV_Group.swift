//
//  LabelingVC_CV_Group.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 17/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import ImageIO

class ThumbnailGroup: UICollectionViewCell {
    @IBOutlet weak var groupNameLabel: UILabel!
}

extension LabelingVC {
    
    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func setupThumbGroupCollectionView() {
        collectionViewThumbGroup.delegate = self
        collectionViewThumbGroup.dataSource = self
        collectionViewThumbGroup.tag = 5
        
        if let layout = collectionViewThumbGroup.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewThumbGroup.backgroundColor = UIColor.black
        
    }
    
    // ================================================================================================================
    // 여기서부터 섬네일 그룹 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_Group(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return subImageList.groupList.count
    }
    
    func cellForItemAt_Group(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDImageGroup", for: indexPath) as! ThumbnailGroup
        if (subImageList.groupList.count == 0) { return cell }
        
        cell.groupNameLabel.text = subImageList.groupList[indexPath.item]
        
        // property mapping
        cell.groupNameLabel.frame = CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height)
        cell.groupNameLabel.lineBreakMode = NSLineBreakMode.byCharWrapping
        cell.groupNameLabel.numberOfLines = 2
        cell.groupNameLabel.textAlignment = .center
        cell.backgroundColor = UIColor.groupTableViewBackground
        cell.layer.borderColor = UIColor.lightGray.cgColor
        cell.layer.borderWidth = 0.3
        
        if (selectedGroupIndex == indexPath.item) {
            cell.groupNameLabel.textColor = UIColor.white
            cell.backgroundColor = GetTintColor()
        }
        else {
            cell.groupNameLabel.textColor = UIColor.black
            cell.backgroundColor = UIColor.groupTableViewBackground
        }
        
        return cell
        
    }
    
    func didSelectItemAt_Group(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (selectedGroupIndex == indexPath.item) { return }
        
        selectedGroupIndex = indexPath.item
        selectedGroupName = subImageList.groupList[indexPath.item]
        collectionViewThumbGroup.reloadData()

        subImageArray = subImageList.imagesByGroup(group: selectedGroupName)
        collectionViewThumbnail.reloadData()

        selectedSubImageRowNum = 0
        
        if (OrientationValue == .landscape) {
            collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
            DoEvents(f: 0.01)
            // ------ 썸네일뷰를 가로 모드에서 좌측위치에 아래로 길게 배열하기 위해서는 아래를 풀고 위를 막음
            //                collectionViewThumbnail.scrollToItem(at: IndexPath(item: centerItemNo, section: 0), at: UICollectionView.ScrollPosition.centeredVertically, animated: false)
        }
        else {
            collectionViewThumbnail.scrollToItem(at: IndexPath(item: selectedSubImageRowNum, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: false)
            DoEvents(f: 0.01)
        }
        
        loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
        //resetWhenImageChanged()
        
    }
    
    func collectionViewLayout_Group(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 1
    }
    
    func collectionViewLayout_Group(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width  = (collectionView.frame.width)/CGFloat(subImageList.groupList.count)
        return CGSize(width: width, height: collectionView.frame.height)
    }
    // ================================================================================================================
    // 여기까지 섬네일 그룹 뷰 델리게이트 영역
    // ================================================================================================================
    
}
