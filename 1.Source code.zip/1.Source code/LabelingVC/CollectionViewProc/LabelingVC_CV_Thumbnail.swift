//
//  LabelingVC_CV_Thumbnail.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 17/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit
import ImageIO

class ThumbnailCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    
    internal var befTextColor:UIColor? = UIColor.white
    internal var befBackColor:UIColor? = UIColor.red
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setdefaultColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        name.textColor = UIColor.white
        name.backgroundColor = UIColor.darkGray
    }
    
    enum ColorType {
        case basic
        case marked
        case selected
    }
    
    func colorType(_ colorType:ColorType) {
        if (colorType == .basic) {
            setdefaultColor()
        }
        else if (colorType == .marked) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.yellow
        }
        else if (colorType == .selected) {
            befTextColor = name.textColor
            befBackColor = name.backgroundColor
            name.textColor = UIColor.white
            name.backgroundColor = GetTintColor()
        }
        else {
            setdefaultColor()
        }
    }
    

}

extension LabelingVC {


    // ================================================================================================================
    // 여기서부터 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_Thumbnail(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return subImageArray.count
    }
    
    func cellForItemAt_Thumbnail(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDImageCell", for: indexPath as IndexPath) as! ThumbnailCell

        if (subImageArray.count == 0) { return cell }
        
        cell.backgroundColor = UIColor.black
        if (indexPath.item >= subImageArray.count) { return cell }
        cell.name.text = subImageArray[indexPath.item].row_num?.description
        
//        if (subImageArray[indexPath.item].newMarking!) {                  // 20200901
//            if (subImageArray[indexPath.item].mark_num! > 0) {
//                cell.colorType(.marked)
//            }
//            else if (subImageArray[indexPath.item].isLabelingDone!) {
//                cell.colorType(.marked)
//            }
//            else {
//                cell.colorType(.basic)
//            }
//            if let img = subImageArray[indexPath.item].newMarkedImage {
//                cell.cellImage.image = img
//            }
//        }
//        else {
            if (subImageArray[indexPath.item].mark_num! > 0) {
                cell.colorType(.marked)
                if (sumImageNeedDownLoad) {
//                    if let file_name = subImageArray[indexPath.item].thu_file_path,         // 20200814
//                        let sourceImagePath = imageArray[currentImageIndex].serverLocation {
//                        p("sourceImagePath : \(sourceImagePath)");
//                        let aaa = getMarkedImagePathOnServer(sourceImageFullPathOnServer: sourceImagePath, sourceSubImageFullPathOnServer: file_name, sequence: 0).relativePath
//
//                        p("mark path : \(aaa)");
//                        let encoded = aaa.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                    }
                    if let file_name = subImageArray[indexPath.item].thu_file_path {  // 20200901 그냥 썸네일 이미지를 보여줌... 가볍게 하기 위함
                        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
                    }
                    else {
                        cell.cellImage.image = nil                   // 디폴트 이미지 세팅
                    }
                }
            }
//            else if subImageArray[indexPath.item].isLabelingDone! {         // 20200819
//                cell.colorType(.marked)
//                if (sumImageNeedDownLoad) {
//                    if let file_name = subImageArray[indexPath.item].thu_file_path {  // 20200814
//                        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
//                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
//                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
//                    }
//                    else {
//                        cell.cellImage.image = nil                   // 디폴트 이미지 세팅
//                    }
//                }
//            }
            else {
                cell.colorType(.basic)
                if (sumImageNeedDownLoad) {
                    if let file_name = subImageArray[indexPath.item].thu_file_path {  // 20200814
                        let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
                        let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
                        cell.cellImage.loadImageUsingUrlString(urlString: url!.absoluteString)
                    }
                    else {
                        cell.cellImage.image = nil                   // 디폴트 이미지 세팅
                    }
                }
            }
        //}
        
        if (selectedSubImageRowNum == indexPath.item) {
            selectedThumbnailCellIndexPath = indexPath
            cell.colorType(.selected)
        }
        
        return cell
        
    }
    
    func didSelectItemAt_Thumbnail(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if (selectedSubImageRowNum == indexPath.item) { return }

        var befCellOK = false
        
        if let befIndexPath = selectedThumbnailCellIndexPath {
            if let befCell = collectionView.cellForItem(at: befIndexPath) as? ThumbnailCell {
                if (subImageArray[selectedSubImageRowNum].newMarking!) {
                    if (subImageArray[selectedSubImageRowNum].mark_num! > 0) {
                        befCell.colorType(.marked)
                    }
                    else {
                        befCell.colorType(.basic)
                    }
                }
                else if (subImageArray[selectedSubImageRowNum].isLabelingDone!) {       // 20200819
                    befCell.colorType(.marked)
                }
                else {
                    if (subImageArray[selectedSubImageRowNum].mark_num! > 0) {
                        befCell.colorType(.marked)
                    }
                    else {
                        befCell.colorType(.basic)
                    }
                }
                befCellOK = true
            }
        }

        let cell = collectionView.cellForItem(at: indexPath) as! ThumbnailCell
        cell.colorType(.selected)
        
        selectedThumbnailCellIndexPath = indexPath
        
        selectedSubImageRowNum = indexPath.item
        loadSubImageOneFromUrl(subImageInfo: subImageArray[selectedSubImageRowNum])
        //resetWhenImageChanged()
        
        if (!befCellOK) {
            collectionViewThumbnail.reloadData()
        }
        
        animation(view: EditingImage, direction: .TopToBottom)
        
        //collectionView.scrollToItem(at: indexPath, at: .centeredHorizontally, animated: false) // 20200821 선택했을 때 가운데로 오게끔. 일단 막음
    }
    
    func collectionViewLayout_Thumbnail(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionViewLayout_Thumbnail(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (OrientationValue == .landscape) {
            return CGSize(width: 70, height: collectionView.frame.height)
        }
        else {
            return CGSize(width: 70, height: collectionView.frame.height)
        }
    }
    // ================================================================================================================
    // 여기까지 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================

}

