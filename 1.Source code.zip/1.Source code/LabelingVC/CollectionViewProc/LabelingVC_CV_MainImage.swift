//
//  LabelingVC_CV_MainImage.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 26/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class MainImageCell: UICollectionViewCell {
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var cellImage: UIImageView!
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setdefaultColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    internal func setdefaultColor() {
        name.textColor = UIColor.white
        name.backgroundColor = UIColor.darkGray
    }
    
    enum ColorType {
        case basic
        case marked
        case drop
        case selected
    }
    
    func colorType(_ colorType:ColorType) {


        if (colorType == .basic) {
            setdefaultColor()
        }
        else if (colorType == .marked) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.yellow
        }
        else if (colorType == .drop) {
            name.textColor = UIColor.black
            name.backgroundColor = UIColor.white
        }
        else if (colorType == .selected) {
            name.textColor = UIColor.white
            name.backgroundColor = GetTintColor()
        }
        else {
            setdefaultColor()
        }
    }
    
}

extension LabelingVC {

    
    // --------------------------------------------------------------------------
    // 섬네일용 컬렉션뷰 기본 설정
    // --------------------------------------------------------------------------
    func setupMainImageCollectionView() {
        collectionViewMainImage.delegate = self
        collectionViewMainImage.dataSource = self
        collectionViewMainImage.tag = 4
        
        if let layout = collectionViewMainImage.collectionViewLayout as? UICollectionViewFlowLayout {
            layout.scrollDirection = .horizontal
        }
        
        collectionViewMainImage.backgroundColor = UIColor.white
        
        imageCache.countLimit = 200
        imageCache.totalCostLimit = 0
    }
    

    
    // ================================================================================================================
    // 여기서부터 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
    func numberOfItemsInSection_MainImage(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return imageArray.count
    }
    
    func cellForItemAt_MainImage(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {

        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "IDMainImageCell", for: indexPath as IndexPath) as! MainImageCell
        if (imageArray.count == 0) { return cell }

        cell.backgroundColor = UIColor.black
        
        if (indexPath.item >= imageArray.count) { return cell }
        cell.name.text = imageArray[indexPath.item].row_num?.description
        
        if (imageArray[indexPath.item].newMarking!) {
            if (imageArray[indexPath.item].markNum! > 0) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isLabelingDone!) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isDrop! == "Y") {
                cell.colorType(.drop)
            }
            else {
                cell.colorType(.basic)
            }
        }
        else {
            if (imageArray[indexPath.item].markNum! > 0) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isLabelingDone!) {
                cell.colorType(.marked)
            }
            else if (imageArray[indexPath.item].isDrop! == "Y") {
                cell.colorType(.drop)
            }
            else {
                cell.colorType(.basic)
            }
        }
        
        if (currentImageIndex == indexPath.item) {
            cell.colorType(.selected)
            selectedMainImageCellIndexPath = indexPath
        }

        return cell
        
    }
    
    func didSelectItemAt_MainImage(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        if (currentImageIndex == indexPath.item) {
            return
        }
        
        var befCellOK = false
        
        if (currentImageIndex >= 0 && currentImageIndex < imageArray.count) {
            if let befIndexPath = selectedMainImageCellIndexPath {
                if let befCell = collectionView.cellForItem(at: befIndexPath) as? MainImageCell {
                    if (imageArray[currentImageIndex].markNum! > 0) {
                        befCell.colorType(.marked)
                    }
                    else if (imageArray[currentImageIndex].isLabelingDone!) {
                        befCell.colorType(.marked)
                    }
                    else if (imageArray[currentImageIndex].isDrop! == "Y") {
                        befCell.colorType(.drop)
                    }
                    else {
                        befCell.colorType(.basic)
                    }
                    befCellOK = true
                }
            }
        }
        else {
            p("Array Index Error : didSelectItemAt_MainImage() number \(currentImageIndex)")
        }

        currentImageIndex = indexPath.item
        let cell = collectionView.cellForItem(at: indexPath) as! MainImageCell
        cell.colorType(.selected)

        selectedMainImageCellIndexPath = indexPath
        loadImageFromURL(index: currentImageIndex)
        
        if (!befCellOK) {
            collectionViewMainImage.reloadData()
        }
    }
    
    func didDeselectItemAt_MainImage(_ collectionView: UICollectionView, didDeselectItemAt indexPath: IndexPath) {
        //p("---------------------------------------------------------------------------------didDeselectItemAt : \(indexPath.item)")
        return
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    func collectionViewLayout_MainImage(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        //p("collectionView.frame.width, collectionView.frame.height : \(collectionView.frame.width), \(collectionView.frame.height)")
        if (OrientationValue == .landscape) {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
        else {
            return CGSize(width: 67, height: collectionView.frame.height - 2)
        }
    }
    // ================================================================================================================
    // 여기까지 섬네일 컬렉션 뷰 델리게이트 영역
    // ================================================================================================================
}
