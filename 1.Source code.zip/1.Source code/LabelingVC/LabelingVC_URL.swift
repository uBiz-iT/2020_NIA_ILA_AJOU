//
//  MainVC_URL.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 26/10/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import Foundation
import UIKit

extension LabelingVC {
    
    enum typeURLRequest:Int {
        case GetLabelList = 0, GetLabelListWithResult, GetImageList, SaveLabelingResult, GetReferImageList, GetSubImageList, End
    }
    
    enum typeJsonParsing:Int {
        case GetLabelList = 0, GetLabelListWithResult, GetImageList, SaveLabelingResult, GetReferImageList, GetSubImageList, Success, ErrorMessage, ErrorCode, End
    }
    

    // =======================================================================================================
    // 서버로부터 프로젝트에 해당하는 라벨 정보 가져오기
    // =======================================================================================================
    func selectLabelList() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let lList:[LabelInfo] =
                self.parseJson(parsingType: .GetLabelList, jsonFormat: json) as? [LabelInfo]
                else { throw ResponseDataError.JsonParsing }
            
            LabelList.arrayLabelInfo = lList
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }
    
    // =======================================================================================================
    // 서버로부터 프로젝트에 해당하는 라벨 정보(라벨링 결과 포함) 가져오기
    // =======================================================================================================
    func selectLabelListWithResult() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetLabelListWithResult)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let lList:[LabelInfo] =
                self.parseJson(parsingType: .GetLabelList, jsonFormat: json) as? [LabelInfo]
                else { throw ResponseDataError.JsonParsing }
            
            LabelList.arrayLabelInfo = lList
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }
    
    // =======================================================================================================
    // 서버에 라벨링 결과 보내기
    // =======================================================================================================
    func saveLabelingResult() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .SaveLabelingResult)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }
    
    // =======================================================================================================
    // 서버로부터 이미지 목록 가져오기
    // =======================================================================================================
    func selectImageList() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetImageList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let imageList:[ImageInfo] =
                self.parseJson(parsingType: .GetImageList, jsonFormat: json) as? [ImageInfo]
                else { throw ResponseDataError.JsonParsing }
            
            mainImageList.append(imageList: imageList)

            result = true

        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }

    // =======================================================================================================
    // 참조 이미지 목록
    // =======================================================================================================
    func getReferImageList() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetReferImageList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
                else { throw ResponseDataError.JsonParsing }
            
            if (!getSuccess) {
                guard let msg:String =
                    self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                    else { throw ResponseDataError.JsonParsing }
                
                LastURLErrorMessage = msg
                
                throw ResponseDataError.ReturnValue
            }
            
            guard let imageInfoList:[ReferImageInfo] =
                self.parseJson(parsingType: .GetReferImageList, jsonFormat: json) as? [ReferImageInfo]
                else { throw ResponseDataError.JsonParsing }
            
            self.referImageList.images = imageInfoList
            
            result = true
            
        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }
    
    // =======================================================================================================
    // 하위 이미지 목록 가져오기
    // =======================================================================================================
    func getSubImageList() -> Bool {
        // ------------------------------------------------
        let requestURL = makeURLRequestForJsonFromServer(requestType: .GetSubImageList)
        var result = false
        
        LastURLErrorMessage = ""
        
        let (success, error, err_code, err_msg, json ) = SendRequestForJSON(requestURL: requestURL)
        
        do {
            if (!success!) {
                if let e = error {
                    throw e
                }
                else {
                    throw ResponseDataError.RequestURLForJSON
                }
            }

            guard let getSuccess = self.parseJson(parsingType: .Success, jsonFormat: json) as? Bool
            else { throw ResponseDataError.JsonParsing }

            if (!getSuccess) {
                guard let msg:String = self.parseJson(parsingType: .ErrorMessage, jsonFormat: json) as? String
                else { throw ResponseDataError.JsonParsing }
             
                LastURLErrorMessage = msg
             
                throw ResponseDataError.ReturnValue
            }

            guard let iList:[SubImageInfo] = self.parseJson(parsingType: .GetSubImageList, jsonFormat: json) as? [SubImageInfo]
            else { throw ResponseDataError.JsonParsing }

            subImageList.append(subImageList: iList)

            result = true
             
        }
        catch let error as RequestURLError {
            if (error == RequestURLError.URLSession) {
                LastURLErrorMessage = "[\(String(describing: err_code!))]" + err_msg!
            }
            else {
                LastURLErrorMessage = error.rawValue
            }
        }
        catch let error as ResponseDataError {
            if (LastURLErrorMessage == "") {
                LastURLErrorMessage = error.rawValue
            }
            p("[ResponseDataError] \(error.rawValue)")
        }
        catch let error as NSError {
            LastURLErrorMessage = error.debugDescription
            p("[NSError  ] \(error.debugDescription)")
        }
        catch let error {
            LastURLErrorMessage = error.localizedDescription
            p("[Error  ] \(error.localizedDescription)")
        }
        
        return result
        
    }

    
    // =======================================================================================================
    // 서버로부터 json 포맷으로 받기 위한 url request 생성하기
    // =======================================================================================================
    func makeURLRequestForJsonFromServer(requestType:typeURLRequest) -> URLRequest? {
        
        var request:URLRequest? = nil
        
        switch requestType {
        case typeURLRequest.GetLabelList:  // 라벨 목록 가져오기
            
            struct RequestLabelList: Codable {
                var proc_name: String?
                var project_cd: String?
            }
            
            var requestLabelList = RequestLabelList();
            requestLabelList.proc_name = "P_GET_LABEL_LIST";
            requestLabelList.project_cd = WorkingProjectCode;
            
            let jsonData = try? JSONEncoder().encode(requestLabelList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetLabelListWithResult:  // 라벨 목록(라벨링 결과 포함)
            
            struct RequestLabelList: Codable {
                var proc_name: String?
                var project_cd: String?
                var user_id: String?
                var labeling_order: Int?
            }
            
            var requestLabelList = RequestLabelList();
            requestLabelList.proc_name = "P_GET_LABEL_LIST_WITH_RESULT";
            requestLabelList.project_cd = WorkingProjectCode;
            requestLabelList.user_id = LoginID;
            requestLabelList.labeling_order = WorkingLabelingOrder;
            
            let jsonData = try? JSONEncoder().encode(requestLabelList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetImageList:  // 이미지 목록
            
            struct RequestImageList: Codable {
                var proc_name: String?
                var project_cd: String?
                var user_id: String?
                var labeling_order: Int?
                var row_num: Int?
            }
            
            var requestImageList = RequestImageList();
            requestImageList.proc_name = "P_GET_IMAGE_LIST"
            requestImageList.user_id = LoginID
            requestImageList.project_cd = WorkingProjectCode
            requestImageList.labeling_order = WorkingLabelingOrder
            requestImageList.row_num = image_last_row_num

            let jsonData = try? JSONEncoder().encode(requestImageList);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData

        case typeURLRequest.SaveLabelingResult:  // 라벨링 결과 저장
            
            var requestSaveLabelingResult = RequestSaveLabelingResult()
            requestSaveLabelingResult.proc_name = "P_SAVE_LABELING_RESULT"
            requestSaveLabelingResult.project_cd = WorkingProjectCode
            requestSaveLabelingResult.user_id = LoginID
            requestSaveLabelingResult.labeling_ord = WorkingLabelingOrder
            requestSaveLabelingResult.image_id = imageArray[currentImageIndex].id
            requestSaveLabelingResult.multi_yn = WorkingProjectMulti
            requestSaveLabelingResult.whole_yn = "Y"                        // 20200827 전체 기본 설정
            if (WorkingProjectMulti == "Y") {
                if (selectedSubImageRowNum >= 0) {
                    requestSaveLabelingResult.sub_image_id = subImageArray[selectedSubImageRowNum].sub_image_id
                }
            }
            else {
                requestSaveLabelingResult.sub_image_id = ""
            }
            requestSaveLabelingResult.mark_num = self.canvas.lines.count
            
            var labelingLocationResult = LabelingResult();
            
            if (LabelList.getLabelCount(location: 0) > 0 && getLastSelectedIndex(0) >= 0) {
                labelingLocationResult.target_cd = 0;
                //labelingLocationResult.label_cd = getLastSelectedIndex(0);
                labelingLocationResult.label_cd = LabelList.getLabelCode(location: 0)[getLastSelectedIndex(0)];
                requestSaveLabelingResult.result.append(labelingLocationResult);
            }
            
            if (LabelList.getLabelCount(location: 1) > 0 && getLastSelectedIndex(1) >= 0) {
                labelingLocationResult.target_cd = 1;
                //labelingLocationResult.label_cd = getLastSelectedIndex(1);
                labelingLocationResult.label_cd = LabelList.getLabelCode(location: 1)[getLastSelectedIndex(1)];
                requestSaveLabelingResult.result.append(labelingLocationResult);
            }
            
            let jsonData = try? JSONEncoder().encode(requestSaveLabelingResult);

            // -------------------------------------------------------------------------------------------
            // 20200828 json을 파일에 저장 추가, 이미지로 업로드시에 json 파일도 업로드. 여기에는 마크 좌표도 함께 저장
            // 마크 좌표 관련 데이터 생성 20200829
            canvas.lines.forEach { (line) in
                var mark = MarkResult()
                mark.type = line.type.rawValue
                mark.isClip = line.isClip
                mark.width = line.width
                mark.color = Color(Red: line.color.redValue, Green: line.color.greenValue, Blue: line.color.blueValue, alpha: line.alpha)
                mark.fillcolor = Color(Red: line.fillcolor.redValue, Green: line.fillcolor.greenValue, Blue: line.fillcolor.blueValue, alpha: line.alpha)
                mark.shape = getRealPoints(screenPoints: getMyPoints(line: line))
                requestSaveLabelingResult.mark_result.append(mark)
            }
            // -------------------------------------------------------------------------------------------

            do {
                let jsonFile = try JSONEncoder().encode(requestSaveLabelingResult);
                try jsonFile.write(to: getJsonFileUrl(), options: [])

                // -----------------------------------------------------------------------------------
                // 20200828 추가 json 업로드
                // 저장된 json 파일 URL을 서버 위치에 업로드. 이미지보다 먼저 올림(이미지는 db에 저장 후 절차임)
                // -----------------------------------------------------------------------------------
                let imageId = imageArray[currentImageIndex].id
                let serverFileName = String(format: "%@%@", ((WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id : imageId)!, markedImageNameSuffix) // 20200828
                let serverSourceImagePath = imageArray[currentImageIndex].serverLocation!
                uploadMarkedIndivisualImage(fileURL: getJsonFileUrl(), imageId: imageId!, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 0, line: nil)

            } catch {
                p("jsonFile write : ", error.localizedDescription)
            }

            // -----------------------------------------------------------------------------
            // 20200928 COCO JSON 파일 저장 파트
            // -----------------------------------------------------------------------------
            var coco_LabelingResult = COCO_LabelingResult()
            coco_LabelingResult.project_cd = WorkingProjectCode
            coco_LabelingResult.user_id = LoginID
            coco_LabelingResult.labeling_order = WorkingLabelingOrder
            
            let df = DateFormatter()
            df.dateFormat = "yyyy-MM-dd HH:mm:ss"
            df.timeZone = TimeZone.current
            let now = df.string(from: Date())
            coco_LabelingResult.labeling_date = now
            
            var coco_Image = COCO_Image();
            coco_Image.file_name = imageArray[currentImageIndex].file_name == nil ? "" :  imageArray[currentImageIndex].file_name
            
            if let image = EditingImage.image {
                coco_Image.height = Int(image.size.height)
                coco_Image.width = Int(image.size.width)
            }
            else {
                coco_Image.height = 0
                coco_Image.width = 0
            }
            coco_Image.id = imageArray[currentImageIndex].id
            
            coco_LabelingResult.image = coco_Image
            
            var coco_Annotation = COCO_Annotation();
            coco_Annotation.image_id = imageArray[currentImageIndex].id
            coco_Annotation.category_id = LabelList.getLabelCode(location: 0)[getLastSelectedIndex(0)];
            
            coco_Annotation.area = 0.0
            
            canvas.lines.forEach { (line) in
                let cocoRealPoints = getRealPoints_COCO(screenPoints: getMyPoints(line: line))
                coco_Annotation.segmentation.append(cocoRealPoints)
                let realPoints = getRealPoints(screenPoints: getMyPoints(line: line))
                coco_Annotation.area = coco_Annotation.area! + getPolygonArea(realPoints)
            }
            coco_LabelingResult.annotation = coco_Annotation
            
            LabelList.getLabelInfoListByLocation(location: 0).forEach { (labelInfo) in
                var coco_Category = COCO_Category()
                coco_Category.id = labelInfo.value
                coco_Category.name = labelInfo.text
                coco_LabelingResult.categories.append(coco_Category)
            }
            
            do {
                let jsonCOCOFile = try JSONEncoder().encode(coco_LabelingResult);
                try jsonCOCOFile.write(to: getJsonFileUrlCOCO(), options: [])

                // -----------------------------------------------------------------------------------
                // 20200828 추가 json 업로드
                // 저장된 json 파일 URL을 서버 위치에 업로드. 이미지보다 먼저 올림(이미지는 db에 저장 후 절차임)
                // -----------------------------------------------------------------------------------
                let imageId = imageArray[currentImageIndex].id
                let serverFileName = String(format: "%@_COCO", ((WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id : imageId)!)
                let serverSourceImagePath = imageArray[currentImageIndex].serverLocation!
                uploadMarkedIndivisualImage(fileURL: getJsonFileUrlCOCO(), imageId: imageId!, serverSourceImagePath: serverSourceImagePath, serverFileName: serverFileName, imageSeq: 1, line: nil)

            } catch {
                p("jsonCOCOFile write : ", error.localizedDescription)
            }
            // -----------------------------------------------------------------------------

            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetReferImageList:
            
            struct RequestReferImage: Codable {
                var proc_name: String?
                var project_cd: String?
                var image_id: String?
            }
            
            var requestReferImage = RequestReferImage();
            requestReferImage.proc_name = "P_GET_REFER_LIST_BY_GROUP"
            requestReferImage.project_cd = WorkingProjectCode
            requestReferImage.image_id = imageArray[currentImageIndex].id
            
            let jsonData = try? JSONEncoder().encode(requestReferImage);
            
            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData
            
        case typeURLRequest.GetSubImageList:  // 하위 이미지 목록
            
            struct RequestSubImageList: Codable {
                var proc_name: String?
                var user_id: String?
                var project_cd: String?
                var labeling_order: Int?
                var image_id: String?
                var row_num: Int?
                var direction: Int?
            }
            
            var requestSubImageList = RequestSubImageList();
            requestSubImageList.proc_name = "P_GET_SUB_IMAGE_LIST"
            requestSubImageList.user_id = LoginID
            requestSubImageList.project_cd = WorkingProjectCode
            requestSubImageList.labeling_order = WorkingLabelingOrder
            requestSubImageList.image_id = imageArray[currentImageIndex].id
            requestSubImageList.row_num = last_row_num
            requestSubImageList.direction = 1
            
            let jsonData = try? JSONEncoder().encode(requestSubImageList);

            // 접속 server url 정의
            // -------------------------------------------------
            let endpoint = ILA4ML_URL_PROC
            guard let endpointUrl = URL(string: endpoint) else {
                p("URL Error : \(endpoint)")
                return nil
            }
            
            // 요청할 최종 url 정의
            // -------------------------------------------------
            request = URLRequest(url: endpointUrl)
            request?.setValue("application/json; charset=utf-8", forHTTPHeaderField: "Content-Type")
            request!.httpMethod = "POST"
            request!.httpBody = jsonData

        default:
            break
        }
        
        return request
        
    }
    
    func getJsonFileUrl() -> URL {
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {                    // 20200901
            p("getJsonFileUrl() : makeDir markedImageDirectoryURL error")
        }
        
        let serverFileName = String(format: "%@%@", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageArray[currentImageIndex].id!, markedImageNameSuffix)
        let jsonFileName = String(format: "%@.json", serverFileName)
        let jsonFileURL = markedImageDirectoryURL!.appendingPathComponent(jsonFileName)
        return jsonFileURL
    }

    // 20200928 COCO json 파일명
    func getJsonFileUrlCOCO() -> URL {
        
        if (!makeDir(fullPath: markedImageDirectoryURL!.path)) {
            p("getJsonFileUrl() : makeDir markedImageDirectoryURL error")
        }
        
        let serverFileName = String(format: "%@_COCO", (WorkingProjectMulti == "Y") ? subImageArray[selectedSubImageRowNum].sub_image_id! : imageArray[currentImageIndex].id!)
        let jsonFileName = String(format: "%@.json", serverFileName)
        let jsonFileURL = markedImageDirectoryURL!.appendingPathComponent(jsonFileName)
        return jsonFileURL
    }
    
    // =======================================================================================================
    // JSON 포맷 파싱
    // =======================================================================================================
    func parseJson(parsingType:typeJsonParsing, jsonFormat:Dictionary<String, Any>?) -> AnyObject? {
        
        let returnAnyObject:Bool = false
        
        guard let json = jsonFormat else {
            p("func parseJson:jsonFormat is nil")
            return returnAnyObject as AnyObject
        }
        
        switch parsingType {
        case typeJsonParsing.Success:  // 성공여부 가져오기
            
            do {
                guard let success = json["success"] as? Bool else {
                    throw ResponseDataError.JsonProtocol
                }
                return success as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
                LastURLErrorMessage = error.rawValue
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
                LastURLErrorMessage = error.debugDescription
            }
            
        case typeJsonParsing.ErrorMessage:  //  에러 메시지 가져오기
            
            do {
                guard let errorMessage = json["err_msg"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorMessage as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.ErrorCode:  //  에러 코드 가져오기
            
            do {
                guard let errorCode = json["err_code"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                return errorCode as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.SaveLabelingResult:  //  저장 결과 회신 메시지에서 총건수와 완료건수 가져오기
            
            do {
                guard let total_count = json["total_count"] as? Int,
                    let complete_count = json["complete_count"] as? Int
                    else {
                        throw ResponseDataError.JsonProtocol
                }
                // 이미지 전체 갯수 및 완료 갯수 저장
                self.total_count = total_count
                self.complete_count = complete_count
                
                // 20190909 label list 추가. 저장 후 바로 라벨링 목록(라벨별 수량 포함)을 가져오기
                var labelList:[LabelInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let lList = json["label_list"] as? [[String: Any]] {
                    for lbl in lList {
                        guard let location:Int = lbl["target_cd"] as? Int,
                            let value:Int = lbl["label_cd"] as? Int,
                            let text:String = lbl["label_desc"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let label = LabelInfo()
                        label.location = location
                        label.value = value
                        label.text = text
                        labelList.append(label)
                    }
                }
                
                if (labelList.count > 0) {
                    LabelList.arrayLabelInfo = labelList
                }
                
                return complete_count as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetLabelList:  // 라벨 목록
            do {
                
                var labelList:[LabelInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["label_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let location:Int = item["target_cd"] as? Int,
                            let value:Int = item["label_cd"] as? Int,
                            let text:String = item["label_desc"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let label = LabelInfo()
                        label.location = location
                        label.value = value
                        label.text = text
                        labelList.append(label)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return labelList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetLabelListWithResult:  // 라벨 목록(라벨링 결과 포함)
            do {
                
                var labelList:[LabelInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["label_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let location:Int = item["target_cd"] as? Int,
                            let value:Int = item["label_cd"] as? Int,
                            let text:String = item["label_desc"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let label = LabelInfo()
                        label.location = location
                        label.value = value
                        label.text = text
                        labelList.append(label)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return labelList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetImageList:  // 이미지 목록
            do {
                
                // 전체 이미지 건수
                guard let count = json["image_count"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                
                self.image_count = count
                
                guard let image_dir = json["image_dir"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                
                var imageList:[ImageInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["image_list"] as? [[String: Any]] {
                    for item in items {
                        //p("item:", item)
                        
                        guard let row_num = item["row_num"] as? Int,
                            let id = item["image_id"] as? String,
                            let file_name = item["file_name"] as? String,
                            let file_path = item["file_path"] as? String,
                            let org_file_path = item["org_file_path"] as? String,
                            let thu_file_path = item["thu_file_path"] as? String,
                            let sub_file_name = item["sub_file_name"] as? String,
                            let labeling_done = item["labeling_done"] as? String,
                            let mark_num = item["mark_num"] as? Int,
                            let isDrop = item["isDrop"] as? String,
                            let t0_label_cd = item["t0_label_cd"] as? Int,
                            let t1_label_cd = item["t1_label_cd"] as? Int
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let image = ImageInfo()
                        image.row_num = row_num
                        image.id = id
                        
                        var temp:URL = URL(fileURLWithPath: image_dir)
                        temp.appendPathComponent(file_name)

                        image.file_name = file_name     // 20200928 COCO
                        
//                        image.serverLocation = temp.relativePath
                        
                        image.serverLocation = file_path
                        image.org_file_path = org_file_path
                        image.thu_file_path = thu_file_path
                            
                        temp = URL(fileURLWithPath: image_dir)
                        temp.appendPathComponent(id)
                        temp.appendPathComponent(sub_file_name)
                        
                        image.sub_serverLocation = temp.relativePath

                        image.isLabelingDone = (labeling_done == "Y") ? true : false
                        image.markNum = mark_num
                        image.isDrop = isDrop

                        var labeling:LabelingLocationResult = LabelingLocationResult()
                        labeling.target_cd = 0
                        labeling.label_cd = t0_label_cd
                        image.labelingResult.append(labeling)
                        
                        labeling = LabelingLocationResult()
                        labeling.target_cd = 1
                        labeling.label_cd = t1_label_cd
                        image.labelingResult.append(labeling)
                        
                        image.newMarking = false
                        image.newMarkedImage = nil
                        
                        imageList.append(image)
                        
                        image_last_row_num = row_num
                    }
                }
                else {
                    p("typeJsonParsing.GetImageList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return imageList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetReferImageList:
            do {
                // 이미지 목록
                var imageList:[ReferImageInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["refer_image_list"] as? [[String: Any]] {
                    for item in items {
                        guard let group:String = item["group_name"] as? String,
                            let image_url:String = item["refer_image_url"] as? String
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let imageInfo = ReferImageInfo()
                        imageInfo.group = group
                        imageInfo.imageUrl = image_url
                        imageList.append(imageInfo)
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return imageList as AnyObject
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            
        case typeJsonParsing.GetSubImageList:  // 하위 이미지 목록
            do {
                
                // 전체 이미지 건수
                guard let count = json["sub_image_count"] as? Int else {
                    throw ResponseDataError.JsonProtocol
                }
                
                self.sub_image_count = count
                
                // 이미지 디렉토리
                guard let image_dir = json["image_dir"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                
                // 가장 마지막 라벨링 이미지
                guard let last_sub_image_id = json["last_sub_image_id"] as? String else {
                    throw ResponseDataError.JsonProtocol
                }
                
                LastLabelingSubImageId = last_sub_image_id
                
                // 이미지 목록
                var imageList:[SubImageInfo] = []
                
                // 하부 구조가 또 있으며 여러개가 있을 경우 대비 [[String: Any]], 하나일 경우 [String: Any]
                // ------------------------------------
                if let items = json["sub_image_list"] as? [[String: Any]] {
                    for item in items {
                        
                        guard let row_num:Int = item["row_num"] as? Int,
                            let image_id:String = item["sub_image_id"] as? String,
                            let file_name:String = item["file_name"] as? String,
                            let sub_file_path:String = item["sub_file_path"] as? String,
                            let org_file_path:String = item["org_file_path"] as? String,
                            let thu_file_path:String = item["thu_file_path"] as? String,
                            let labeling_done = item["labeling_done"] as? String,   // 20200819
                            let group:String = item["group"] as? String,
                            let t0_label_cd = item["t0_label_cd"] as? Int,          // 20200820
                            let mark_num:Int = item["mark_num"] as? Int
                            else { throw ResponseDataError.JsonProtocol }
                        
                        let imageInfo = SubImageInfo()
                        imageInfo.row_num = row_num
                        imageInfo.sub_image_id = image_id
                        
                        var temp:URL = URL(fileURLWithPath: image_dir)
                        temp.appendPathComponent(imageArray[currentImageIndex].id!)
                        temp.appendPathComponent(file_name)

                        //imageInfo.sub_server_location = temp.relativePath
                        
                        imageInfo.sub_server_location = sub_file_path   // 20200814
                        imageInfo.org_file_path = org_file_path
                        imageInfo.thu_file_path = thu_file_path
                        
                        imageInfo.mark_num = mark_num
                        imageInfo.group = group
                        imageInfo.newMarking = false
                        imageInfo.newMarkedImage = nil
                        imageInfo.isLabelingDone = (labeling_done == "Y") ? true : false  // 20200819
                        
                        var labeling:LabelingLocationResult = LabelingLocationResult()    // 20200820
                        labeling.target_cd = 0
                        labeling.label_cd = t0_label_cd
                        imageInfo.labelingResult.append(labeling)
                        
                        labeling = LabelingLocationResult()
                        labeling.target_cd = 1
                        labeling.label_cd = -1                                            // 무조건 -1 20200820. 타겟이 하나
                        imageInfo.labelingResult.append(labeling)

                        imageList.append(imageInfo)
                        //self.subImageList.append(imageInfo)
                        last_row_num = row_num
                    }
                }
                else {
                    p("typeJsonParsing.GetLabelList else")
                    throw ResponseDataError.JsonProtocol
                }
                
                return imageList as AnyObject
                
            }
            catch let error as ResponseDataError {
                p("[ResponseDataError] \(error.rawValue)")
            }
            catch let error as NSError {
                p("[NSError  ] \(error.debugDescription)")
            }
            

        default:
            break
        }
        
        return returnAnyObject as AnyObject
        
    }
    
}

