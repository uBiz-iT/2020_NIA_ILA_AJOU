//
//  SlideReferImagesVC_CV.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 01/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension SlideReferImagesVC: UICollectionViewDelegate, UICollectionViewDataSource {

    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        if (collectionView == self.collectionViewGroupName) {
            return referImageList.groupList.count
        }
        else {
            if (selectedGroupName == "") {
                return 0
            }
            else {
                return referImageList.imagesByGroup(group: selectedGroupName).count
            }
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        // 메인 이미지 컬렉션
        if (collectionView == self.collectionView) {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "collectionView", for: indexPath) as! SlideReferImagesData
            
            if let file_name = referImageList.imagesByGroup(group: selectedGroupName)[indexPath.item].imageUrl {
                let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
                let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
                cell.img.loadImageUsingUrlString(urlString: url!.absoluteString)
            }
            cell.setScrollViewPropertyForImage()
            return cell
        }
        // 썸네일 컬렉션
        else if (collectionView == self.imageThumbnail) {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageThumbnail", for: indexPath) as! SlideReferThumbnail
            if let file_name = referImageList.imagesByGroup(group: selectedGroupName)[indexPath.item].imageUrl {
                let encoded = file_name.addingPercentEncoding(withAllowedCharacters: .alphanumerics)
                let url = URL(string: "\(ILA4ML_URL_GETIMAGE)?file_name=\(encoded!)")
                cell.img.loadImageUsingUrlString(urlString: url!.absoluteString)
            }
            return cell
        }
        else {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "referImageGroupName", for: indexPath) as! ReferImageGroupName
            
            cell.referImageGroupName.text = referImageList.groupList[indexPath.item]
            // property mapping
            cell.referImageGroupName.frame = CGRect(x: 0, y: 0, width: cell.frame.width, height: cell.frame.height)
            cell.referImageGroupName.lineBreakMode = NSLineBreakMode.byCharWrapping
            cell.referImageGroupName.numberOfLines = 2
            cell.referImageGroupName.textAlignment = .center
            cell.backgroundColor = UIColor.groupTableViewBackground
            cell.layer.borderColor = UIColor.lightGray.cgColor
            cell.layer.borderWidth = 0.3
            
            if (selectedGroupIndex == indexPath.item) {
                cell.referImageGroupName.textColor = UIColor.white
                cell.backgroundColor = GetTintColor()
            }
            else {
                cell.referImageGroupName.textColor = UIColor.black
                cell.backgroundColor = UIColor.groupTableViewBackground
            }
                

            return cell
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        if (collectionView == self.collectionView) {
        }
        else if (collectionView == self.imageThumbnail) {
            self.collectionView.scrollToItem(at: IndexPath(item: indexPath.item, section: 0), at: UICollectionView.ScrollPosition.centeredHorizontally, animated: true)
            DoEvents(f: 0.01)
        }
        else {
            selectedGroupIndex = indexPath.item
            selectedGroupName = referImageList.groupList[indexPath.item]
            p("selectedGroupIndex, selectedGroupName : \(selectedGroupIndex), \(selectedGroupName)")
            collectionViewGroupName.reloadData()
            imageThumbnail.reloadData()
            self.collectionView.reloadData()
        }
    }
    
}

extension SlideReferImagesVC: UICollectionViewDelegateFlowLayout {
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        if (collectionView == self.collectionView) {
            let size = collectionView.frame.size
            return CGSize(width: size.width, height: size.height)
        }
        else if (collectionView == self.imageThumbnail) {
            let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "imageThumbnail", for: indexPath) as? SlideReferThumbnail
            return CGSize(width: cell!.img.frame.size.width - 1, height: cell!.img.frame.size.height)
        }
        else {
            let width  = (collectionView.frame.width)/CGFloat(referImageList.groupList.count)
            return CGSize(width: width, height: collectionView.frame.height)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, insetForSectionAt section: Int) -> UIEdgeInsets {
        if (collectionView == self.collectionView) {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
        else if (collectionView == self.imageThumbnail) {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
        else {
            return UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        if (collectionView == self.collectionView) {
            return 0
        }
        else if (collectionView == self.imageThumbnail) {
            return 0
        }
        else {
            return 0
        }
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        if (collectionView == self.collectionView) {
            return 0
        }
        else if (collectionView == self.imageThumbnail) {
            return 1
        }
        else {
            return 0
        }
    }
    
    override func viewWillTransition(to size: CGSize, with coordinator: UIViewControllerTransitionCoordinator) {
        if (collectionView == self.collectionView) {
            collectionView.reloadData()
        }
        else if (collectionView == self.imageThumbnail) {
            collectionView.reloadData()
        }
        else {
            collectionView.reloadData()
        }
        //super.viewWillTransition(to: size, with: coordinator)
    }
}
