//
//  ConsolePrint.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 14/11/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// -----------------------------------------------------------------------
// print 맨 앞에 시간 출력
// -----------------------------------------------------------------------
public func p(_ items: Any..., separator: String = " ", terminator: String = "\n") {
    let output = items.map { "\($0)" }.joined(separator: separator)
    Swift.print("\(myDate.millsecondsToStringWithSeperator):", output, terminator: terminator)
}

// -----------------------------------------------------------------------
// 현재 시간을 특정 포맷으로 콘솔에 출력
// -----------------------------------------------------------------------
func DateToString() -> String {
    let d = Date()
    let df = DateFormatter()
    df.dateFormat = "y-MM-dd HH:mm:ss.SSS"
    
    return df.string(from: d)
}

func TimeToString() -> String {
    let d = Date()
    let df = DateFormatter()
    df.dateFormat = "HH:mm:ss.SSS"

    return df.string(from: d)
}

class myDate {
    
    static var toStringWithSeperator: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "y-MM-dd HH:mm:ss.SSS"
            return df.string(from: d)
        }
    }
    static var toString: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "yMMddHHmmssSSS"
            return df.string(from: d)
        }
    }
    static var dateToString: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "yMMdd"
            return df.string(from: d)
        }
    }
    static var dateToStringWithSeperator: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "y-MM-dd"
            return df.string(from: d)
        }
    }
    static var millsecondsToString: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "HHmmssSSS"
            return df.string(from: d)
        }
    }
    static var millsecondsToStringWithSeperator: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "HH:mm:ss.SSS"
            return df.string(from: d)
        }
    }
    static var timeToString: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "HHmmss"
            return df.string(from: d)
        }
    }
    static var timeToStringWithSeperator: String {
        get {
            let d = Date()
            let df = DateFormatter()
            df.dateFormat = "HH:mm:ss"
            return df.string(from: d)
        }
    }
}
