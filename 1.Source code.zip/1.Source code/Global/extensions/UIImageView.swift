//
//  UIImageView.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 18/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension UIImageView {
    // ------------------------------------------------------------------
    // imageview안에 표시되어 있는 image frame 가져오기
    // ------------------------------------------------------------------
    var frameOfImage:CGRect {
        let image = self.image!
        let wi = image.size.width
        let hi = image.size.height
        //p("wi:\(wi), hi:\(hi)")
        
        let wv = self.frame.width
        let hv = self.frame.height
        //p("wv:\(wv), hv:\(hv)")
        
        let ri:Double = Double(hi) / Double(wi)
        let rv:Double = Double(hv) / Double(wv)
        //p("ri:\(ri), rv:\(rv)")
        
        var x, y, w, h: Double
        
        if ri > rv {
            h = Double(hv)
            w = h / ri
            x = (Double(wv) / 2) - (w / 2)
            y = 0
        } else {
            w = Double(wv)
            h = w * ri
            x = 0
            y = (Double(hv) / 2) - (h / 2)
        }
        
        return CGRect(x: x, y: y, width: w, height: h)
    }
    
    // ------------------------------------------------------------------
    // uiimageview frame 대비 실제 image 크기의 비율 가져오기
    // ------------------------------------------------------------------
    var imageScale:CGFloat {
        // scrollimage의 폭 대비 높이 비율
        let rateOfImageViewHeightByWidth = self.frame.size.height / self.frame.size.width
        let rateOfRealImageHeightByWidth = self.image!.size.height / self.image!.size.width
        
        var scale:CGFloat
        
        if (rateOfImageViewHeightByWidth > rateOfRealImageHeightByWidth) {
            scale = (self.image?.size.width)! / self.frame.size.width
            //p("extension UIImageView : originalImageByViewScale Height base : ", scale)
        }
        else {
            scale = (self.image?.size.height)! / self.frame.size.height
            //p("extension UIImageView : originalImageByViewScale Width Base: ", scale)
        }
        return scale
    }
    
    // ------------------------------------------------------------------
    // 실제 이미지 크기 대비 uiimageview frame 비율 가져오기
    // ------------------------------------------------------------------
    var frameScale:CGFloat {
        // scrollimage의 폭 대비 높이 비율
        let rateOfImageViewHeightByWidth = self.frame.size.height / self.frame.size.width
        let rateOfRealImageHeightByWidth = self.image!.size.height / self.image!.size.width
        
        var scale:CGFloat
        
        if (rateOfImageViewHeightByWidth > rateOfRealImageHeightByWidth) {
            scale = self.frame.size.width / (self.image?.size.width)!
            //p("extension UIImageView : frameScale Height base : ", scale)
        }
        else {
            scale = self.frame.size.height / (self.image?.size.height)!
            //p("extension UIImageView : frameScale Width Base: ", scale)
        }
        return scale
    }
    
    func drawFrame(frame:CGRect, color:UIColor, width:CGFloat) -> UIView {
        let frameIdentifyBorderView = UIView(frame: frame)
        frameIdentifyBorderView.layer.borderWidth = width
        frameIdentifyBorderView.layer.borderColor = color.cgColor
        self.addSubview(frameIdentifyBorderView)
        return frameIdentifyBorderView
    }
    
}

extension UIImageView {
    // ------------------------------------------------------------------------------------
    // 이미지 뷰를 동그랗게
    // ------------------------------------------------------------------------------------
    func setRounded() {
        let radius = self.frame.width / 2
        self.layer.cornerRadius = radius
        self.layer.masksToBounds = true
    }
    
    // ------------------------------------------------------------------------------------
    // 이미지 뷰에 설정된 이미지의 Rect
    // ------------------------------------------------------------------------------------
    func imageRect() -> CGRect {
        let imageViewSize = self.frame.size
        let imgSize = self.image?.size
        
        guard let imageSize = imgSize, imgSize != nil else {
            return CGRect.zero
        }
        
        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height
        let aspect = fmin(scaleWidth, scaleHeight)
        
        var imageRect = CGRect(x: 0, y: 0,
                               width: CGFloat(imageSize.width * aspect),
                               height: CGFloat(imageSize.height * aspect))
        // Center image
        imageRect.origin.x = CGFloat((imageViewSize.width - imageRect.size.width) / 2)
        imageRect.origin.y = CGFloat((imageViewSize.height - imageRect.size.height) / 2)
        
        // Add imageView offset
        imageRect.origin.x += self.frame.origin.x
        imageRect.origin.y += self.frame.origin.y
        
        return imageRect
    }
    
    // ------------------------------------------------------------------------------------
    // 이미지 뷰에 설정된 이미지의 원점
    // ------------------------------------------------------------------------------------
    func imageOrigin() -> CGPoint {
        let imageViewSize = self.frame.size
        let imgSize = self.image?.size
        
        guard let imageSize = imgSize, imgSize != nil else {
            return CGPoint.zero
        }
        
        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height
        let aspect = fmin(scaleWidth, scaleHeight)
        
        var imageRect = CGRect(x: 0, y: 0,
                               width: CGFloat(imageSize.width * aspect),
                               height: CGFloat(imageSize.height * aspect))
        // Center image
        imageRect.origin.x = CGFloat((imageViewSize.width - imageRect.size.width) / 2)
        imageRect.origin.y = CGFloat((imageViewSize.height - imageRect.size.height) / 2)
        
        // Add imageView offset
        imageRect.origin.x += self.frame.origin.x
        imageRect.origin.y += self.frame.origin.y
        
        imageRect.origin.x = imageRect.origin.x.rounded()
        imageRect.origin.y = imageRect.origin.y.rounded()
        
        return imageRect.origin
    }
    
    // ------------------------------------------------------------------------------------
    // 이미지 뷰에 설정된 이미지의 사이즈
    // ------------------------------------------------------------------------------------
    func imageSize() -> CGSize {
        let imageViewSize = self.frame.size
        let imgSize = self.image?.size
        
        guard let imageSize = imgSize, imgSize != nil else {
            return CGSize.zero
        }
        
        let scaleWidth = imageViewSize.width / imageSize.width
        let scaleHeight = imageViewSize.height / imageSize.height
        let aspect = fmin(scaleWidth, scaleHeight)
        
        let imageRectSize = CGSize(width: CGFloat(imageSize.width * aspect),
                                   height: CGFloat(imageSize.height * aspect))
        return imageRectSize
    }
}


extension UIImageView {
    
    override open func touchesBegan(_ touches: Set<UITouch>, with event: UIEvent?) {
        //p("extension UIImageView : touchesBegan")
        self.next?.touchesBegan(touches, with: event)
    }
    
    override open func touchesMoved(_ touches: Set<UITouch>, with event: UIEvent?) {
        //p("extension UIImageView : touchesMoved")
        self.next?.touchesMoved(touches, with: event)
    }
    
    override open func touchesEnded(_ touches: Set<UITouch>, with event: UIEvent?) {
        //p("extension UIImageView : touchesEnded")
        self.next?.touchesEnded(touches, with: event)
    }
    
    override open func touchesCancelled(_ touches: Set<UITouch>, with event: UIEvent?) {
        //p("extension UIImageView : touchesCancelled")
        self.next?.touchesEnded(touches, with: event)
    }
    
}
