//
//  UICollectionView.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 2020/08/21.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension UICollectionView {

    func hasItemAtIndexPath(indexPath: NSIndexPath) -> Bool {
        return indexPath.section < self.numberOfSections && indexPath.item < self.numberOfItems(inSection: indexPath.section)
    }
}
