//
//  UserDefaults.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 30/11/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

// user defualt key 정의
// ==============================================================================
let DefaultKey_ServerAddress = "ServerAddress"
let DefaultKey_isLogin = "isLogin"
let DefaultKey_loginId = "LoginID"
let DefaultKey_loginName = "LoginName"

// ==============================================================================
let DefaultKey_isWorking = "isWorking"
let DefaultKey_ProjectCode = "ProjectCode"
let DefaultKey_ProjectName = "ProjectName"
let DefaultKey_ProjectImageDir = "ProjectImageDir"                      // 20200826
let DefaultKey_ProjectMulti = "ProjectMulti"                            // 20200825 "N"이었는데 변경함. 실수
let DefaultKey_ProjectMark = "ProjectMark"                              // 20200825 "N"이었는데 변경함. 실수
let DefaultKey_ProjectSaveMarkImage = "ProjectSaveMarkImage"            // 20200910
let DefaultKey_LabelingOrder = "LabelingOrder"
let DefaultKey_ImageIndex = "ImageIndex"
let DefaultKey_ImageId = "ImageId"                                      // 풀 스캔 모드에서 마지막 조회된 이미지
let DefaultKey_SubImageIndex = "SubImageIndex"                          // 20200820
let DefaultKey_SubImageId = "SubImageId"                                // 20200820
let DefaultKey_LastLabelingImageId = "LastLabelingImageId"
let DefaultKey_LastLabelingSubImageId = "LastLabelingSubImageId"        // 20200819

class MyUserDefaults {

    func getUserDefaultAfterDidBecomeActive() {
        // tint color 가져오기
        // ------------------------------------------------------------------------
        let userDefaultTintColor = UserDefaults.standard.integer(forKey: TintColorKey)
        if let defaultColor = EnumTintColor(rawValue: userDefaultTintColor)?.color {
            SetTintColor(color: defaultColor)
        }
        else {
            SetTintColor(color: EnumTintColor(rawValue: 0)!.color)
        }
        
        // 세로가로모드 가져오기
        // ------------------------------------------------------------------------
        let userDefaultOrientation = UserDefaults.standard.integer(forKey: OrientationKey)
        if let defaultOrientation = EnumOrientation(rawValue: userDefaultOrientation)?.orientation {
            OrientationValue = defaultOrientation
        }
        else {
            OrientationValue = UIInterfaceOrientationMask.portrait
        }
    }
    
    // ------------------------------------------------------------------------
    // user default value 가져오기
    // ------------------------------------------------------------------------
    func getUserDefaults() {
        
        p("------------------------------ userdefault loading result ---------------------------------")
        // 서버 접속 주소
        // ------------------------------------------------------------------------
        if let addr = UserDefaults.standard.string(forKey: DefaultKey_ServerAddress) {
            p("addr : \(addr)")
            SetServerAddress(addr)
        }
        
        // 로그인 여부
        // ------------------------------------------------------------------------
        isLogin = UserDefaults.standard.bool(forKey: DefaultKey_isLogin)
        
        LoginID = ""
        LoginName = "Not signed."
        
        // 로그인 정보
        // ------------------------------------------------------------------------
        if let id = UserDefaults.standard.string(forKey: DefaultKey_loginId) {
            LoginID = id
        }
        if (isLogin) {
            if let name = UserDefaults.standard.string(forKey: DefaultKey_loginName) {
                LoginName = name
            }
        }
        
        p("getUserDefault : ", LoginName)
        
        // 라벨링 작업 현황
        // ------------------------------------------------------------------------
        isWorking = UserDefaults.standard.bool(forKey: DefaultKey_isWorking)
        
        WorkingProjectCode = ""
        WorkingProjectName = "프로젝트 미설정"
        WorkingProjectMulti = "N"
        WorkingProjectMark = "N"
        WorkingProjectSaveMarkImage = "N"   // 20200910

        WorkingLabelingOrder = 0
        WorkingImageIndex = 0
        WorkingImageId = ""
        LastLabelingImageId = ""
        
        if (isWorking) {

            // 라벨링 중인 프로젝트 코드
            // ------------------------------------------------------------------------
            if let code = UserDefaults.standard.string(forKey: DefaultKey_ProjectCode) {
                WorkingProjectCode = code
            }

            // 라벨링 중인 프로젝트 명
            // ------------------------------------------------------------------------
            if let name = UserDefaults.standard.string(forKey: DefaultKey_ProjectName) {
                WorkingProjectName = name
            }
            
            // 라벨링 중인 프로젝트 이미지 메인 디렉토리  20200826
            // ------------------------------------------------------------------------
            if let name = UserDefaults.standard.string(forKey: DefaultKey_ProjectImageDir) {
                WorkingProjectImageDir = name
            }
            
            // 라벨링 중인 프로젝트 멀티 레이어 여부
            // ------------------------------------------------------------------------
            if let multi = UserDefaults.standard.string(forKey: DefaultKey_ProjectMulti) {
                WorkingProjectMulti = multi
            }
            
            // 라벨링 중인 프로젝트 마킹 여부
            // ------------------------------------------------------------------------
            if let mark = UserDefaults.standard.string(forKey: DefaultKey_ProjectMark) {
                WorkingProjectMark = mark
            }
            
            // 라벨링 중인 프로젝트 마킹 여부
            // ------------------------------------------------------------------------
            if let saveImage = UserDefaults.standard.string(forKey: DefaultKey_ProjectSaveMarkImage) {
                WorkingProjectSaveMarkImage = saveImage
            }
            
            // 라베링 중인 프로젝트의 차수
            // ------------------------------------------------------------------------
            WorkingLabelingOrder = UserDefaults.standard.integer(forKey: DefaultKey_LabelingOrder)

            // 라벨링 중인 이미지 인덱스
            // ------------------------------------------------------------------------
            WorkingImageIndex = UserDefaults.standard.integer(forKey: DefaultKey_ImageIndex)

            // 작업중이었던 이미지 id
            // ------------------------------------------------------------------------
            if let workingImageId = UserDefaults.standard.string(forKey: DefaultKey_ImageId) {
                WorkingImageId = workingImageId
            }

            // 마지막 라벨링 이미지 id
            // ------------------------------------------------------------------------
            if let lastLabelingImageId = UserDefaults.standard.string(forKey: DefaultKey_LastLabelingImageId) {
                LastLabelingImageId = lastLabelingImageId
            }

            // 20200820 여기서부터는 서브이미지에 대한 것
            // 라벨링 중인 이미지 인덱스
            // ------------------------------------------------------------------------
            WorkingSubImageIndex = UserDefaults.standard.integer(forKey: DefaultKey_SubImageIndex)

            // 작업중이었던 이미지 id
            // ------------------------------------------------------------------------
            if let workingSubImageId = UserDefaults.standard.string(forKey: DefaultKey_SubImageId) {
                WorkingSubImageId = workingSubImageId
            }

            // 마지막 라벨링 이미지 id
            // ------------------------------------------------------------------------
            if let lastLabelingSubImageId = UserDefaults.standard.string(forKey: DefaultKey_LastLabelingSubImageId) {
                LastLabelingSubImageId = lastLabelingSubImageId
            }

        }
        if (isLogin) {
            let rp = RequestProject()
            if (rp.projectList()) {
                setWorkingProjectInfo()
            }
            else {
                var topWindow: UIWindow? = UIWindow(frame: UIScreen.main.bounds)
                topWindow?.rootViewController = UIViewController()
                topWindow?.windowLevel = UIWindow.Level.alert + 1
                let alert: UIAlertController = UIAlertController(title: "메세지 확인", message: LastURLErrorMessage, preferredStyle: .alert)
                alert.addAction(UIAlertAction.init(title: "확인", style: .default, handler: {(alertAction) in
                    topWindow?.isHidden = true
                    topWindow = nil
                }))
                topWindow?.makeKeyAndVisible()
                topWindow?.rootViewController?.present(alert, animated: true, completion: nil)
            }
        }
        
        p("isLogin : \(isLogin)")
        p("LoginName : \(LoginName)")
        p("isWorking : \(isWorking)")
        p("WorkingProjectCode : \(WorkingProjectCode)")
        p("WorkingProjectName : \(WorkingProjectName)")
        p("WorkingProjectMulti : \(WorkingProjectMulti)")
        p("WorkingLabelingOrder : \(WorkingLabelingOrder)")
        p("WorkingImageIndex : \(WorkingImageIndex)")
        p("WorkingImageId : \(WorkingImageId)")
        p("LastLabelingImageId : \(LastLabelingImageId)")
        p("WorkingSubImageIndex : \(WorkingSubImageIndex)")
        p("WorkingSubImageId : \(WorkingSubImageId)")
        p("LastLabelingSubImageId : \(LastLabelingSubImageId)")
        p("-----------------------------------------------------------------------------------------")
        
    }
    
    // ---------------------------------------------------------------------
    // 현재 프로젝트 및 차수 정보 세팅 및 저장
    // ---------------------------------------------------------------------
    func setWorkingProjectInfo() {
        
        isWorking = false
        
        for project in ProjectList {
            if (project.working!) {
                isWorking = true
                WorkingProjectCode = project.code!
                WorkingProjectName = project.name!
                WorkingProjectImageDir = project.image_dir!                 // 20200826
                WorkingProjectMulti = project.multi_yn!
                WorkingProjectMark = project.mark_yn!
                WorkingProjectSaveMarkImage = project.mark_image_save_yn!   // 20200910
                WorkingLabelingOrder = project.labeling_ord!
                //WorkingImageIndex = 0 
                WorkingImageId = project.cur_image_id!
                LastLabelingImageId = project.last_image_id!
                break;
            }
        }
        
        UserDefaults.standard.set(isWorking, forKey: DefaultKey_isWorking)
        UserDefaults.standard.set(WorkingProjectCode, forKey: DefaultKey_ProjectCode)
        UserDefaults.standard.set(WorkingProjectName, forKey: DefaultKey_ProjectName)
        UserDefaults.standard.set(WorkingProjectImageDir, forKey: DefaultKey_ProjectImageDir)           // 20200826
        UserDefaults.standard.set(WorkingProjectMulti, forKey: DefaultKey_ProjectMulti)
        UserDefaults.standard.set(WorkingProjectMark, forKey: DefaultKey_ProjectMark)
        UserDefaults.standard.set(WorkingProjectSaveMarkImage, forKey: DefaultKey_ProjectSaveMarkImage) // 20200910
        UserDefaults.standard.set(WorkingLabelingOrder, forKey: DefaultKey_LabelingOrder)
        UserDefaults.standard.set(WorkingImageIndex, forKey: DefaultKey_ImageIndex)
        UserDefaults.standard.set(WorkingImageId, forKey: DefaultKey_ImageId)
        UserDefaults.standard.set(LastLabelingImageId, forKey: DefaultKey_LastLabelingImageId)
        UserDefaults.standard.set(WorkingSubImageIndex, forKey: DefaultKey_SubImageIndex)               // 20200820
        UserDefaults.standard.set(WorkingSubImageId, forKey: DefaultKey_SubImageId)                     // 20200820
        UserDefaults.standard.set(LastLabelingSubImageId, forKey: DefaultKey_LastLabelingSubImageId)    // 20200820

    }

}
