//
//  ProjectVC.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 05/11/2018.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

class ProjectVC: UITableViewController {
    
    @IBOutlet var loginNameLabel: UILabel!
    @IBOutlet var tableViewProject: UITableView!
    
    var selectedProjectInfo = ProjectInfo()
    var selectedProjectSection = -1
    var selectedProjectIndex = -1

    // color set
    let workingTextColor = UIColor.black
    let workingBackColor = ColorWithHexString(hexString: "#87CEFA")
    let normalTextColor = UIColor.black
    let normalBackColor = UIColor.white
    let selectedWorkingTextColor = UIColor.blue
    let selectedWorkingBackColor = ColorWithHexString(hexString: "#DCDCDC")
    let selectedNormalTextColor = UIColor.black
    let selectedNormalBackColor = ColorWithHexString(hexString: "#DCDCDC")

    var projectSections = [ProjectSection]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.title = "프로젝트 목록"
    }

    override func viewWillAppear(_ animated: Bool) {
        SetOrientation()
        super.viewWillAppear(animated)
    }
    
    var viewDidAppearCount = 0
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        viewDidAppearCount = viewDidAppearCount + 1
        if (viewDidAppearCount == 1) {
            didTapReloadButton(self)
            p("didTapReloadButton(self)")
        }
    }
    
    // ---------------------------------------------------------------------
    // 프로젝트 목록 갱신(서버 요청)
    // ---------------------------------------------------------------------
    @IBAction func didTapReloadButton(_ sender: Any) {
        loadProjectList()
    }
    
    func loadProjectList() {
        
        if (!isLogin) { return }
        
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)

        DoEvents(f: 0.01)     // 20200827

        let rp = RequestProject()
        if (rp.projectList()) {
            let ud = MyUserDefaults()
            ud.setWorkingProjectInfo()

            // tableview section처리를 위하여...
            selectedProjectSection = -1
            selectedProjectIndex = -1
            self.projectSections = ProjectSection.group(headlines: ProjectList)
            self.tableView.reloadData()
        }
        else {
            let alertProgressNoAction = UIAlertController(title: "메시지 확인", message: "\n\n\(LastURLErrorMessage)\n\n", preferredStyle: .alert)
            let otherAction = UIAlertAction(title: "확인", style: .default, handler: { action in
                //self.dismiss(animated: true, completion: nil)
                alertProgressNoAction.dismiss(animated: true, completion: nil)
            })
            alertProgressNoAction.addAction(otherAction)
            self.present(alertProgressNoAction, animated: false, completion: nil)
        }

        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()

    }
    
    // ---------------------------------------------------------------------
    // 라벨링 시작/종료 이벤트 처리
    // ---------------------------------------------------------------------
    enum enumBeginEndType:String {
        case Begin = "BEGIN", End = "END"
    }
    
    var beginEndType = enumBeginEndType.End
    
    @IBAction func projectBeginEndButtonTapped(_ sender: Any) {
        let button = sender as! UIButton
        let tag = button.tag

        if (tag == 1) {
            // 프로젝트 라벨링 시작 처리
            if (selectedProjectIndex < 0) {
                self.view.showToast(toastMessage: "선택된 프로젝트가 없습니다.", duration: 1.5)
                return
            }
            beginEndType = enumBeginEndType.Begin
            if (processBeginEnd()) {
                self.performSegue(withIdentifier: "unwindFromNewProject", sender: self)
            }
        }
        else if (tag == 0) {

            self.performSegue(withIdentifier: "unwindFromProjectList", sender: self)

        }
    }

    func processBeginEnd() -> Bool {
        var success = false
        // ------------------------------------------------
        // 스피너 시작
        // ------------------------------------------------
        let child = SpinnerViewController()
        child.view.frame = self.view.frame
        self.view.addSubview(child.view)
        child.didMove(toParent: self)
        
        DoEvents(f: 0.01)     // 20200827

        if (projectBeginEnd()) {
            let rp = RequestProject()
            if (rp.projectList()) {

                // tableview section처리를 위하여...
                self.projectSections = ProjectSection.group(headlines: ProjectList)

                let ud = MyUserDefaults()
                ud.setWorkingProjectInfo()
                
                // tableview 반영
                selectedProjectSection = -1
                selectedProjectIndex = -1
                self.tableView.reloadData()
                
                switch beginEndType {
                case enumBeginEndType.Begin:
                    self.view.showToast(toastMessage: "정상적으로 시작되었습니다.", duration: 0.5)
                    break
                case enumBeginEndType.End:
                    selectedProjectSection = -1
                    selectedProjectIndex = -1
                    self.view.showToast(toastMessage: "정상적으로 종료되었습니다.", duration: 0.5)
                    break
                }
                success = true
            }
            else {
                let alertProgressNoAction = UIAlertController(title: "메세지 확인\n\n\n", message: nil, preferredStyle: .alert)
                let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                    //self.dismiss(animated: true, completion: nil)
                    alertProgressNoAction.dismiss(animated: true, completion: nil)
                })
                alertProgressNoAction.addAction(otherAction)
                self.present(alertProgressNoAction, animated: false, completion: nil)
            }
        }
        else {
            let alertProgressNoAction = UIAlertController(title: "메세지 확인\n\n\n", message: nil, preferredStyle: .alert)
            let otherAction = UIAlertAction(title: "OK", style: .default, handler: { action in
                alertProgressNoAction.dismiss(animated: true, completion: nil)
            })
            alertProgressNoAction.addAction(otherAction)
            self.present(alertProgressNoAction, animated: false, completion: nil)
        }
        
        // ------------------------------------------------
        // 스피너 종료
        // ------------------------------------------------
        child.willMove(toParent: nil)
        child.view.removeFromSuperview()
        child.removeFromParent()
        

        return success
    }
    
}
