//
//  SlideReferImagesVC_Gesture.swift
//  ILA_AJOU
//
//  Created by Myeong-Joon Son on 29/07/2020.
//  Copyright © 2020 uBiz Information Technology. All rights reserved.
//

import UIKit

extension SlideReferImagesVC {

    func initGesture() {
        setupTapGestureRecognizer(numberOfTouches: 1, numberOfTaps: 2)
    }
    
    //--------------------------------------------------------------------------------
    // Tap Gesture Set
    //--------------------------------------------------------------------------------
    func setupTapGestureRecognizer(numberOfTouches:Int, numberOfTaps:Int) {
        let tapGesture = UITapGestureRecognizer(target: self, action: #selector(imageTapped(_:)))
        tapGesture.numberOfTouchesRequired = numberOfTouches
        tapGesture.numberOfTapsRequired = numberOfTaps
        collectionView.addGestureRecognizer(tapGesture)
    }
    
    @objc func imageTapped(_ gesture: UITapGestureRecognizer) {
        
        if (gesture.numberOfTouchesRequired == 1) {
            if (gesture.numberOfTapsRequired == 2) {
                unloadMe()
            }
        }
        else if (gesture.numberOfTouchesRequired == 2) {
            // 이미지 Zooming 초기화:Reload
            if (gesture.numberOfTapsRequired == 1) {
                collectionView.reloadData()
            }
        }
    }
    
}
